/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package centralizedvivaldi;

/**
 *
 * @author thuydt
 */
public enum ErrorType {
    ABSOLUTE_ERROR,
    RELATIVE,
    RMSE,
    SQUARE_ERROR
}
