/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package centralizedvivaldi;
import common.*;
import vivaldi.HeightCoordinate;
import vivaldi.vivaldiPosition;

public class Run{
    

	
// a case study for the King363 dataset
    
    public static void runKing363(int dim, int num_iteration, boolean init_coord) throws Exception{    
        
        //intt_coord: FALSE means randomly; TRUE = from a file
        //int dim = 6;
        int height = 0;
        //int num_iteration = 1000;
        String in_base_folder = "./data/King363/input/";
        String out_base_folder = "./data/King363/centralizedVivaldi_output_111717/";
        String fnorm_file = "KingData_363_Norm.csv";
        
        String[] known_file = {"e20n363","e40n363","e60n363","e80n363","e100n363","w_short","w_long"};                
        String[] fhat_file = {"fhat_e20n363m","fhat_e40n363m","fhat_e60n363m","fhat_e80n363m",
                              "fhat_e100n363m","fhat_w_shortm","fhat_w_longm"};
        String[] init_coords_file = {"e20n363_coords_m", "e40n363_coords_m", "e60n363_coords_m", 
                                    "e80n363_coords_m", "e100n363_coords_m", "w_shortn363_coords_m","w_longn363_coords_m"};
        String[] out_coords_file = {"","","","","","",""};
        double[] w = {20,40,60,80,100,1,-1};
        
        for (int i = 0; i < fhat_file.length; i++) {
            fhat_file[i] = fhat_file[i] + String.valueOf(dim);
            out_coords_file[i] = out_base_folder + init_coords_file[i] + String.valueOf(dim);
            init_coords_file[i] = out_base_folder + init_coords_file[i] + String.valueOf(dim-1);
        }
        
        if (!init_coord) 
            for (int i = 0; i < fhat_file.length; i++)
                init_coords_file[i] = "";
        
        int num_known = known_file.length;        
        num_known = 3;
        cVivaldi cv = new cVivaldi();
        for (int i = 2; i < num_known; i++)
               cv.pureVivaldi(in_base_folder + fnorm_file, 
                       in_base_folder+known_file[i], 
                       out_base_folder+fhat_file[i],
                       dim, height,
                       num_iteration,
                       init_coords_file[i], out_coords_file[i]);                       
        
        String original_f_file = "KingData_363.csv";
        
        double[][] F = Files.readFile(in_base_folder + original_f_file);
        if (F == null) return;
        
        double[][] avoided = Matrices.getPosition(F, -1); 
        
        if (avoided == null) return;
        
        double[][] rmse = new double[num_known][2];
        double[][] mre = new double[num_known][2];
        double[][] errorMat = new double[num_known][5];

        double[][] actualMat = Files.readFile(in_base_folder + fnorm_file);

        for (int i = 2; i < num_known; i++) {

            double[][] predictedMat = Files.readFile(out_base_folder + fhat_file[i]);
            double[][] knownMat = Files.readFile(in_base_folder + known_file[i]);

            rmse[i] = EmpiricalError.RMSE(actualMat, predictedMat, knownMat, avoided);
            mre[i] = EmpiricalError.error_RelativeMean_Symmetric(actualMat, predictedMat, knownMat, avoided);

            errorMat[i][0] = w[i]; 
            errorMat[i][1] = rmse[i][0]; errorMat[i][2] = rmse[i][1];
            errorMat[i][3] = mre[i][0]; errorMat[i][4] = mre[i][1];
            }

            String error_file = out_base_folder + "rmse_mre_m" + String.valueOf(dim)+"e60i30000.csv";
            Files.saveFile(errorMat, error_file);         
    }
    
   /* public static void runSeattle99() throws Exception{    
        
        int dim = 2;
        int height = 0;
        int num_iteration = 1000;
        
        String in_base_folder = "./data/Seattle/Input/";
        String out_base_folder = "./data/Seattle/centralizedVivaldi_output_5000/";
        String fnorm_file = "SeattleData_2_rtt_norm.csv";
        
        String[] known_file = {"w20n99","w40n363","w60n363","w80n363","w100n363","w_short","w_long"};                
        String[] fhat_file = {"fhat_w20n99m2","fhat_w40n363m2","fhat_w60n363m2","fhat_w80n363m2","fhat_w100n363m2","fhat_w_shortm2","fhat_w_longm2"};     
        double[] w = {20,40,60,80,100,1,-1};
        
        int num_known = known_file.length;        
        
        for (int i = 0; i < num_known; i++)
               pureVivaldi(in_base_folder + fnorm_file, 
                       in_base_folder+known_file[i], 
                       out_base_folder+fhat_file[i],
                       dim, height,
                       num_iteration);        
        
        
        double[][] rmse = new double[num_known][2];
        double[][] mre = new double[num_known][2];
        double[][] errorMat = new double[num_known][5];

        double[][] actualMat = File.readFile(in_base_folder + fnorm_file);

        for (int i = 0; i < num_known; i++) {

            double[][] predictedMat = File.readFile(out_base_folder + fhat_file[i]);
            double[][] knownMat = File.readFile(in_base_folder + known_file[i]);

            rmse[i] = EmpiricalError.RMSE(actualMat, predictedMat, knownMat);
            mre[i] = EmpiricalError.error_RelativeMean_Symmetric(actualMat, predictedMat, knownMat);

            errorMat[i][0] = w[i]; 
            errorMat[i][1] = rmse[i][0]; errorMat[i][2] = rmse[i][1];
            errorMat[i][3] = mre[i][0]; errorMat[i][4] = mre[i][1];
        }

        String error_file = out_base_folder + "rmse_mre_m2.csv";
        File.saveFile(errorMat, error_file);         
    }
*/
    public static void runPlanetlab(int dim, int num_iteration, boolean init_coord) throws Exception {
        //int num_iteration = 1000;
        //int dim = 4;
        int height = 0; // or 1 = with height

        String data_base_folder = "./data/planetlab/Input/";
        String out_base_folder = "./data/planetlab/centralizedVivaldi_output_111717/";

        String[] known_file = {"e20n490","e40n490","e60n490","e80n490"};
        String[] fhat_file = {"fhat_e20n490m","fhat_e40n490m","fhat_e60n490m","fhat_e80n490m"};
        double[] w = {20, 40, 60, 80};

        String[] init_coords_file = {"e20n490_coords_m", "e40n490_coords_m", "e60n490_coords_m", 
                                    "e80n490_coords_m"};
        String[] out_coords_file = {"","","",""};
        
        
        for (int i = 0; i < fhat_file.length; i++) {
            fhat_file[i] = fhat_file[i] + String.valueOf(dim);
            out_coords_file[i] = out_base_folder + init_coords_file[i] + String.valueOf(dim);
            init_coords_file[i] = out_base_folder + init_coords_file[i] + String.valueOf(dim-1);
        }
        
        if (!init_coord) 
            for (int i = 0; i < fhat_file.length; i++)
                init_coords_file[i] = "";
        
        String fnorm_file = "PlanetLabData_1_Norm.csv";

        int num_known = known_file.length;
        num_known = 1;
        cVivaldi cv = new cVivaldi();
        for (int i = 0; i < num_known; i++)
           cv.pureVivaldi(data_base_folder + fnorm_file, 
                   data_base_folder+known_file[i], 
                   out_base_folder+fhat_file[i],
                   dim, height, num_iteration,
                   init_coords_file[i], out_coords_file[i]);

        double[][] rmse = new double[num_known][2];
        double[][] mre = new double[num_known][2];
        double[][] errorMat = new double[num_known][5];

        double[][] actualMat = Files.readFile(data_base_folder + fnorm_file);

        for (int i = 0; i < num_known; i++) {

                    double[][] predictedMat = Files.readFile(out_base_folder + fhat_file[i]);
                    double[][] knownMat = Files.readFile(data_base_folder + known_file[i]);

                    rmse[i] = EmpiricalError.RMSE(actualMat, predictedMat, knownMat);
                    mre[i] = EmpiricalError.error_RelativeMean_Symmetric(actualMat, predictedMat, knownMat);

                    errorMat[i][0] = w[i]; 
                    errorMat[i][1] = rmse[i][0]; errorMat[i][2] = rmse[i][1];
                    errorMat[i][3] = mre[i][0]; errorMat[i][4] = mre[i][1];
            }

            String error_file = out_base_folder + "rmse_mre_m" + String.valueOf(dim) + "e20i16000noinitcoords.csv";
            Files.saveFile(errorMat, error_file);
    }
	

    
    public static void main(String[] args) throws Exception{
        
        boolean init_coord = false;
        //runKing363(3, 30000, init_coord);
        runPlanetlab(3, 16000, init_coord);
        //runPlanetlab(7, 10000);
        //runSeattle99();
        //runPlanetlab();
        System.out.println("done!");
    }
}
        
