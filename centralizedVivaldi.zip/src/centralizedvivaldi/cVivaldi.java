/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//This package is to implement the vivaldi function with centralized version
//The origin paper is https://www.cs.umd.edu/class/spring2007/cmsc711/papers/vivaldi.pdf

package centralizedvivaldi;
import common.Files;
import common.Matrices;
import java.util.Arrays;
import vivaldi.*;
public class cVivaldi {
    
    public double error(double[][] L, vivaldiPosition[] x, ErrorType et){
        
        double ret = 0;
        int num_point = x.length;
        
        if (null != et) switch (et) {
            case ABSOLUTE_ERROR:{
                double e = 0;
                for (int i = 0; i < num_point; i++){
                    for (int j = 0; j < i; j ++){
                        
                        if ((L[i][j] <= 0) || (L[i][j] > vivaldiPosition.MAX_RTT)) continue;
                        
                        e = e + Math.abs(L[i][j] - x[i].hCoordinate.distance(x[j].hCoordinate));
                    }
                }       
                ret = e * 2;
                break;
            }
            case RELATIVE:{
                double e = 0;
                for (int i = 0; i < num_point; i++){
                    for (int j = 0; j < i; j ++){
                        
                        if ((L[i][j] <= 0) || (L[i][j] > vivaldiPosition.MAX_RTT)) continue;
                        
                        e = e + Math.abs(L[i][j] - x[i].hCoordinate.distance(x[j].hCoordinate))/L[i][j];
                    }
                }       
                ret = e * 2;
                break;
            }
            case SQUARE_ERROR:{
                double e = 0;
                for (int i = 0; i < num_point; i++){
                    for (int j = 0; j < i; j ++){
                        
                        if ((L[i][j] <= 0) || (L[i][j] > vivaldiPosition.MAX_RTT)) continue;
                        
                        e = e + Math.pow(L[i][j] - x[i].hCoordinate.distance(x[j].hCoordinate), 2);
                    }
                }       
                ret = e * 2;
                break;
            }
            case RMSE:{
                double e = 0;
                int count = 0;
                for (int i = 0; i < num_point; i++){
                    for (int j = 0; j < i; j ++){
                        
                        if ((L[i][j] <= 0) || (L[i][j] > vivaldiPosition.MAX_RTT)) continue;
                        
                        e = e + Math.pow(L[i][j] - x[i].hCoordinate.distance(x[j].hCoordinate), 2);
                        count ++;
                    }
                }       
                if (count > 0)
                    ret = Math.sqrt(e/count);
                break;
            }
            default:
                break;
        }
        return ret;
    }
    
    //this function is to compute vivaldiPosition x[]
    
    public void compute_coordinates(double[][] L, vivaldiPosition x[], int num_iteration){
        
        if ((L == null) || (x == null)) return;
        
        int num_coordinates = x.length;
       
        if (L.length != num_coordinates) return;
        
        int dim = x[0].hCoordinate.v.length; 
        HeightCoordinate F;
        
        double re, w, delta, scale;
        double sw, ses;
        
        int num_known = 0;
        for (int i = 0; i<num_coordinates; i++)
            for (int j = 0; j < num_coordinates; j++){
                if ((L[i][j] <= 0) || (L[i][j] >vivaldiPosition.MAX_RTT)) continue;
                num_known++;
            }
        
        for (int loop = 0; loop < num_iteration; loop++){
            double relativeErr = error(L, x, ErrorType.RELATIVE) / (double)num_known;
         //   System.out.println(String.valueOf(relativeErr) + "," + String.valueOf(loop));
            
            for (int i = 0; i < num_coordinates; i++){
                
                F = new HeightCoordinate(new double[dim], 0);
                sw = 0; ses = 0; int num_F = 0;
                
                for (int j = 0; j < num_coordinates; j++){
                
                    if ((i == j) || (L[i][j] <= 0) || (L[i][j]) > vivaldiPosition.MAX_RTT) continue;
                    
                    w = x[i].error + x[j].error; 
                    if (w == 0) continue;
                    w = x[i].error / w; sw = sw + w;
                    
                    num_F += 1;
                    
                    re = L[i][j] - x[i].hCoordinate.distance(x[j].hCoordinate); //real error 
                    ses = ses + Math.abs(re)/L[i][j];                            //relative error
                    
                    double[] noise = new double[dim];
                    for (int k = 0; k < dim; k++) noise[k] = Math.random()/10;
        
                    HeightCoordinate randomHC = new HeightCoordinate(noise, 0);

                    HeightCoordinate uij = x[i].hCoordinate.sub(x[j].hCoordinate.add(randomHC)).unity();
                    delta = vivaldiPosition.cc * w;
                    scale = delta * re;

                    F = F.add(uij.scale(scale)); //compute the force vector (2)
                
                }

                if (num_F > 0) {
                    F = F.scale(1.0/(double)(num_F));
                    sw = sw/(float)(num_F);
                    ses = ses/(float)(num_F);
                }
                
                double new_error = ses * vivaldiPosition.ce * sw + x[i].error * (1 - vivaldiPosition.ce * sw);
                
                if (Double.isFinite(new_error) && (F.isValid())){
                    
                    x[i].hCoordinate = x[i].hCoordinate.add(F);
                    x[i].error = new_error > vivaldiPosition.ERROR_MIN? new_error: vivaldiPosition.ERROR_MIN;
                    
                }else
                {
                    x[i].hCoordinate = new HeightCoordinate(new double[dim], 0);
                    x[i].error = vivaldiPosition.initial_error;
                }
                if (!F.atOrigin()) x[i].nbUpdate++;
                if (x[i].nbUpdate > vivaldiPosition.CONVERGE_EVERY){
                    x[i].nbUpdate = 0;
                    vivaldiPosition vp = new vivaldiPosition(new HeightCoordinate(new double[dim],  0), vivaldiPosition.CONVERGE_FACTOR);
                    x[i].update(10, vp);
                }
            }
        }
    }
    
//this functions is to compute vivaldi Positions from a file of coordinate
//in the file, each column represent one element of a coordinate
//if height = 1, the last column is for the height
    
    
    public vivaldiPosition[] coordinates_fromFile(String init_coord_file, int dim, int height) throws Exception{
        
        double[][] coords = Files.readFile(init_coord_file);
        
        if (coords == null) return null;
        int num_coords = coords.length;
        int lower_dim = coords[0].length;
        vivaldiPosition[] A = new vivaldiPosition[num_coords];
        if (height == 0){   // no height 
        
            for (int i = 0; i < num_coords; i++){
                
                double[] tmp = new double[dim];
                
                for (int j = 0; j < lower_dim ; j++)
                    tmp[j] = coords[i][j];
                
                HeightCoordinate hc = new HeightCoordinate(tmp, 0);
                
                A[i] = new vivaldiPosition(hc); // error of this vivaldiPossition is default value taken from the vivaldiPosition class             
            }    
        }else{
            
            for (int i = 0; i < num_coords; i++){
            
                double[] tmp = new double[dim];
                
                for (int j = 0; j < lower_dim - 1; j++)
                    tmp[j] = coords[i][j];
                
                HeightCoordinate hc = new HeightCoordinate(tmp, coords[i][lower_dim-1]);
                
                A[i] = new vivaldiPosition(hc); // error of this vivaldiPossition is default value taken from the vivaldiPosition class       
            }
        }        
        return A;
    }
    
    //this function is to compute the distances between every pair of nodes
    //given:
    //fnormMat: a symmetric dissimilarity matrix, it is normalized in range [0..1]
    //knownMat: a known matrix of 0|1 values, 1-> known value, 0-> unknown or avoided values
    //dim: dimension of points in the Euclidean embedding
    //height = 0|1, 0: no height, 1: with height
    //init_coord_file: file name of initial coordinates in lower dimension, 
    //if "", => the function will randomly pick initial coordinates
    //out_coords_file: file name of output coordinates, if "", no file will be saved
    
    //output: a matrix of Euclidean distances between pairs of nodes
    
    public double[][] vivaldiMat(double[][] fnormMat, double[][] knownMat, 
        int dim, int height, int num_iteration, 
        String init_coord_file,
        String out_coords_file) throws Exception{

        if ((fnormMat == null) || (knownMat == null)) return null;

        int N = fnormMat.length;
        if (N != fnormMat[0].length) return null;

        if (N != knownMat.length) return null;
        if (N != knownMat[0].length) return null;
        
        vivaldiPosition[] A;

        if (!init_coord_file.equals(""))
        {
            A = coordinates_fromFile(init_coord_file, dim, height);
        }else{
        //randomly create points in dim dimensions, each point is HeightCoordinate if no initial coordinates given
            A = new vivaldiPosition[N];
            double[] a_random = new double[dim];
            
            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < dim; j++) a_random[j] = Math.random();
                HeightCoordinate hc = new HeightCoordinate(a_random, Math.random() * height);
                A[i] = new vivaldiPosition(hc);
            }
        }
        double[][] F = Matrices.dotProduct(fnormMat, knownMat);

        //cVivaldi cv = new cVivaldi();
        //cv.
        compute_coordinates(F, A, num_iteration);

        if (!out_coords_file.equals("")){ //save the coordinates to a file
            double[][] coords;
            if (height == 1){ //with height in the last column
                coords = new double[N][dim+1];
                for (int i = 0; i < N; i++){
                    for (int j = 0; j < dim; j++)
                        coords[i][j] = A[i].hCoordinate.v[j];
                    coords[i][dim] = A[i].hCoordinate.h;
                }
            }else{
                coords = new double[N][dim];
                for (int i = 0; i < N; i++){
                    for (int j = 0; j < dim; j++)
                        coords[i][j] = A[i].hCoordinate.v[j];                    
                }
            }
            Files.saveFile(coords, out_coords_file);
        }
                
        double[][] Fhat = new double[N][N] ;
        for (int i = 0; i < N; i++)
            for (int j = 0; j < i; j++) {
                Fhat[i][j] = A[i].hCoordinate.distance(A[j].hCoordinate);
                Fhat[j][i] = Fhat[i][j];
            }	

        return Fhat;
    }

//this function is to call the vivaldiMat function.
    
//given: fnorm_file: dissimilarity matrix in a file, normalized in the range [0..1]
//       known_file: known matrix in a file of 0|1, 0: unknown|avoided value, 1: known value
//       ... other parameters are same as vivaldiMat()
//output: the distance matrix in a file: fhat_file
//        the coordinate matrix in a file: out_coords_file. If "" => coordinates are NOT saved
//
    
    public void pureVivaldi(String fnorm_file, String known_file, String fhat_file,
                                   int dim, int height, int num_iteration, 
                                   String init_coords_file,
                                   String out_coords_file) throws Exception {         
        
        double[][] fnormMat = Files.readFile(fnorm_file);
        if (fnormMat == null) return;
        
        double[][] knownMat = Files.readFile(known_file);
        if (knownMat == null) return;
        
        double[][] fhatMat = vivaldiMat(fnormMat, knownMat, dim, height, num_iteration,
                                        init_coords_file,
                                        out_coords_file);
        
        Files.saveFile(fhatMat, fhat_file);  
    }
    //unit test
    public static void main(String[] args) {
        int N = 3; int dim =3;int height = 0;
        double[][] L = {{0, 0.5, 0.2}, 
                        {0.5, 0, 0.4},
                        {0.2, 0.4, 0}};
        
        vivaldiPosition[] A = new vivaldiPosition[N];
        double[] a_random = new double[dim];
        for (int i = 0; i < N; i++)
        {
                for (int j = 0; j < dim; j++) a_random[j] = Math.random();
                //System.out.println(Arrays.toString(a_random));
                HeightCoordinate hc = new HeightCoordinate(a_random, Math.random() * height);
                A[i] = new vivaldiPosition(hc);

        }
        System.out.println("After random, points for A:");
        for (int i =0; i< N; i++ )
            System.out.println(Arrays.toString(A[i].hCoordinate.v));
        
        ErrorType et = ErrorType.SQUARE_ERROR;
        double ev = 0.000001;
        
        cVivaldi cv = new cVivaldi();
        
        cv.compute_coordinates(L, A, 1000);

        System.out.println("After vivaldi coordinate of points in A:");
        for (int i =0; i< N; i++ )
            System.out.println(Arrays.toString(A[i].hCoordinate.v));

        double[][] Fhat = new double[N][N] ;
        for (int i = 0; i < N; i++)
            for (int j = 0; j < i; j++) {
                Fhat[i][j] = A[i].hCoordinate.distance(A[j].hCoordinate);
                Fhat[j][i] = Fhat[i][j];
            }	

        System.out.println("Fhat:");
        for (int i = 0; i < N; i++)
            System.out.println(Arrays.toString(Fhat[i]));
        
        System.out.println("L:");
        for (int i = 0; i < N; i++)
            System.out.println(Arrays.toString(L[i]));

    }
}
