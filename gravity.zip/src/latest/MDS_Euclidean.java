// IMPLEMENTATION OF CLASSICAL MULTIDIMENSIONAL SCALING (Euclidean Embedding)
package latest;
import java.util.ArrayList;
import java.util.Collections;

import Jama.*;

public class MDS_Euclidean {
	int n; // num of points
	double[][] F; // input dissim matrix	
	
	int embed_dim=0;
	double[][] X=null; // image points in the embedding	
	private double embed_err=-1;
	
	// variables for convenience
	private Matrix eigenV; // eigenvector matrix
	private Matrix eigenD; // eigenvalue matrix
	private boolean eigen_ready = false;
	
	MDS_Euclidean(double[][] F1) {
		if (MyMatrix.max(F1) > 1 || MyMatrix.min(F1) <0) {
			System.err.println("MDS_Euclidean(): Input dissim matrix must be normalized to [0, 1]");
			System.exit(-1);
		}
		
		if (MyMatrix.isSymmetric(F1)==false) {
			System.err.println("MDS_Euclidean(): Input dissim matrix must be symmatric");
			System.exit(-1);
		}
		
		F = MyMatrix.copy(F1);
		n = F.length;	
	}
	
	private void eigenProcessing() {
		// assuming a complete matrix F	
		if(eigen_ready) {
			// prevent multiple calls to this function
			// if called before, no need to call again
			return;
		}
		// compute D2 = square matrix of F
		double[][] D2 = new double[n][n];
		for (int i=0; i< n; i++) {
			for (int j=0; j < i; j++) {
				D2[i][j] = F[i][j]*F[i][j];
				D2[j][i] = D2[i][j];
			}
		}
		
		// C = centering matrix
		double[][] C = new double[n][n];
		for (int i=0; i< n; i++) {
			C[i][i] = 1.0 - 1.0 / (double) (n);
			for (int j=0; j < i; j++) {
				C[i][j] = -1.0/(double)n;
				C[j][i] = C[i][j];
			}
		}	
		
		// B =-1/2 * C * D2 * C
		Matrix mC = new Matrix(C);
		Matrix mB = mC.times(-0.5);
		mB = mB.times(new Matrix(D2));
		mB = mB.times(mC);

		EigenvalueDecomposition e = mB.eig();
		Matrix V1 = e.getV();
		Matrix D1 = e.getD(); 
		
		// rearrange eigen matrices in descending order of eigenvalues
		int[] index_list = EigenValueIndex.sortEigen(D1);
		eigenD = new Matrix(n, n);
	    for (int i=0; i<n; i++) 
	    	 eigenD.set(i, i, D1.get(index_list[i], index_list[i]));
		
	    eigenV = new Matrix(n, n);
	    for (int row=0; row<n; row++) 
	    	 for (int column=0; column<n; column++) 
	    		 eigenV.set(row, column, V1.get(row, index_list[column]));
		
	    eigen_ready = true;
	}
	
	static double[][] distance(double[][] X) {
		//  distance matrix 
		if (X==null) return null;
		int n=X.length;
		double[][] mat = new double[n][n];
		for (int i=0; i<n;i++)
			for (int j=0; j<i; j++) {
				mat[i][j] = Misc.euclideanDist(X[i], X[j]);
				mat[j][i] = mat[i][j];
			}
		return mat;
	}
	
	double getEmbedError() {
		if (X==null) {
			embed_err = -1;
			return -1;
		}
		if (embed_err != -1) {
	    	// error already computed
	    	return embed_err;
	    }
	    embed_err = InputCommon.error("rmse", F, distance(X));
		return embed_err;
	}
	

	boolean embed(int m) {
		// embed in m-dimension		
		eigenProcessing();
		embed_dim = m;
		embed_err = -1; 
		
		int num_positive_eigen = 0;
		for(int i=0; i<n; i++) 
			if (eigenD.get(i, i) > 0) num_positive_eigen++;
		
		// only extract the part of largest eigenvalues that are positive
		if (m > num_positive_eigen) {
			System.err.println("too few positive eigenvalues: embed dimension " + m + " is too high, should be <=  " + num_positive_eigen);	    	 
			embed_dim = 0;
	    	X = null;
			embed_err = -1;
	    	return false; // unsuccessful
	    }
	     
	    // extract the part corresponding to m largest (positive) eigenvalues
	    Matrix D1 = eigenD.getMatrix(0, m-1, 0, m-1);
	    Matrix V1 = eigenV.getMatrix(0, n-1, 0, m-1);

	     // compute square root matrix of E1
	     for (int i=0; i<m; i++)
	    	 D1.set(i, i, Math.sqrt(D1.get(i, i)));
	     
	    Matrix solutionX = V1.times(D1); // each row of solutionX is position X[i]
	    X = solutionX.getArray();
	    embed_err = getEmbedError();
		return true; // successful
	}
	
	boolean embed(int min_m, int max_m)  {
		// find the best dimension and embed in it
		double min = Double.MAX_VALUE;
		int best_m=0;
		double[][] best_X=null;
		
		boolean success = false;
		
		for (int m=min_m; m <= max_m; m++) {
			if (embed(m)) {
				if (embed_err < min) {
					min = embed_err;
					best_m = m;
					best_X = MyMatrix.copy(X);
					success = true;
				}
			}
		}
		
		if (!success) {
			// fail embedding
			embed_dim = 0;
			X = null;
			embed_err = -1;
			return false;
		}
		//success
		embed_dim = best_m;
		X = best_X;
		embed_err = getEmbedError();
		return success;
	}
		
}

class EigenValueIndex implements Comparable<EigenValueIndex> {
	int index;
	Double value;

	public EigenValueIndex(int index, double value) {
		this.index = index; this.value = value;
	}

	@Override
	public int compareTo(EigenValueIndex o) { 
		return o.value.compareTo(value); 
	}
	
	public static int[] sortEigen(Matrix E) {
		// E is a diagonal matrix
		// sort E in descending order of eigenvalues (diagonal values of E)
		int n = E.getRowDimension();
		// output the indices in increasing order of eigen values
		int[] index_list = new int[n];
		
		ArrayList<EigenValueIndex> eigenValueIndices = new ArrayList<EigenValueIndex>();
		for(int i=0; i<n; i++) eigenValueIndices.add(new EigenValueIndex(i, E.get(i, i)));
		Collections.sort(eigenValueIndices); // increasing value order
		
		int row = 0;
	    for (EigenValueIndex eigen: eigenValueIndices) {
	    	index_list[row] = eigen.index;
	    	row++;
	    }
	    return index_list;
	}
}