// IMPLEMENTATION OF CLASSICAL MULTIDIMENSIONAL SCALING
package latest;
import java.util.ArrayList;

public class MDS_Euclidean_Partial {
	private int n; // num of points
	private double[][] F; // input dissim matrix	

	private double[][] W; // weight of reliability of F[i][j]; zero if F[i][j] is missing or not useful
	private ArrayList<ArrayList<Integer>> listKnown; // listKnown[i] is set of j such that E[i][j]=true
	
	// embedding output
	private int embed_dim=0; //2D, 3D, 4D, ...?
	double[][] X=null; // image points in the embedding	
	double[][] dist; // distance matrix of X
	
	

	MDS_Euclidean_Partial(double[][] F1) {
		if (MyMatrix.max(F1) > 1 || MyMatrix.min(F1) <0) {
			System.err.println("MDS_Euclidean_Partial(): Input dissim matrix must be normalized to [0, 1]");
			System.exit(-1);
		}
		
		if (MyMatrix.isSymmetric(F1)==false) {
			System.err.println("MDS_Euclidean_Partial(): Input dissim matrix must be symmatric");
			System.exit(-1);
		}
		
		F = MyMatrix.copy(F1);
		n = F.length;	
		
	}
	
	MDS_Euclidean_Partial(double[][] F1, double[][] W1) {
		// used when we need to embed a partially observed matrix
		this(F1);
		W = MyMatrix.copy(W1);	
		listKnown = new ArrayList<ArrayList<Integer>>();
		for (int i=0; i<n; i++) {
			ArrayList<Integer> list_i = new ArrayList<Integer>();
			for (int j=0; j<n; j++) 
				if (W[i][j]>0 && i!=j && F[i][j]>0) {
					// known and valid
					list_i.add(j);
				}
			if (list_i.size() <=1) {
				System.err.println("MDS_Euclidean_Partial(): bad known_matrix (node " + i + " has <=1 known values)");
				System.exit(-1);
			}
			listKnown.add(list_i);			
		}
	}	
	

	void embed(int dim, int num_network_iterations, int num_node_iterations) {
		embed_dim = dim;		
		
		// W[i][j] = weight of known F[i][j] 
		// this algorithm is an iterative algorithm
		
		// initialization; make sure X cannot be the origin point, or else may LOOP forever
		X = new double[n][embed_dim]; 
		for (int i=0; i<n; i++) 
			for (int j=0; j<embed_dim; j++) X[i][j] = Math.random();
			
		// iterative algorithm to revise X
		for (int count=0; count < num_network_iterations; count++) {
			for (int i=0; i<n; i++) {
				// update X[i];
				
				// list of points whose dissimilarity with i is known
				ArrayList<Integer> list = listKnown.get(i);						
				if (list.size()==0) continue;
				
				double[][] y = new double[list.size()][embed_dim];
				double[] distances = new double[y.length];
				double[] weight = new double[y.length];
				for (int j=0; j<y.length; j++) {
					int j1 = list.get(j);
					y[j] = X[j1];
					distances[j] = F[i][j1];
					weight[j] = W[i][j1];
				}
				X[i] = multilateration(X[i], y, distances, weight, num_node_iterations); // 10 is good enough  
			}
//			double[] err = InputCommon.error(InputCommon.error_to_optimize, F, MDS_Euclidean.distance(X),E);
//			System.err.println(err[0] + "," + err[1]);
		}
		dist = MDS_Euclidean.distance(X);
	}
	private double[] multilateration(double[] x_init, double[][] y, double[] distances, double[] weight, int num_iterations) {
		// given points, find the point that is a euclidean-distance away from each of those points
		
		// make sure weight must be normalized such that sum is 1 
		double[] w = new double[y.length];
		double weight_sum=0;
		for (int j=0; j<y.length; j++) weight_sum += weight[j];
		for (int j=0; j<y.length; j++) w[j] = weight[j]/ weight_sum;	
		
		double[] x = x_init;		
		
		for (int count=0; count<num_iterations; count++) {
			double[] new_x = new double[embed_dim];
			for (int j=0; j<y.length; j++) {
				double dist = Misc.euclideanDist(x, y[j]);
				if (dist == 0) {
					// x is at same position with y[j]
					// simply move x  away from y[j] along a random direction, within distances[j] distance
					for (int i=0; i<embed_dim; i++) {
						double displacement = distances[j]*Math.random()/Math.sqrt((double) embed_dim);
						new_x[i] += w[j]*(x[i]+displacement);
					}
				}
				else {
					double scale = 1.0 - distances[j]/dist;
					if(Double.isInfinite(scale)) {
						// this case is possible when dist is TOO SMALL ==> scale TOO BIG
						// JAVA cannot handle TOO BIG double numbers, hence setting scale= -INFINITE
						scale = -1; // move opposite direction, doubling distance
					}
					for (int i=0; i<embed_dim; i++) {
						double displacement = (y[j][i]-x[i])*scale;
						new_x[i] += w[j]*(x[i] + displacement); 	
					}
				}
			}
			x = new_x;
		}
		return x;
	}
	
}
