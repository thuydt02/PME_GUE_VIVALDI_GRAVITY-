package latest;
import java.util.ArrayList;

public class MDS_Riemannian_Partial {
	MDS_Riemannian mds;
	
	private int n;
	private int riemannian_dim; // Riemannian dimension (m-sphere, m-hyperbolic)
	private double[][] W; 	// non-negative weight matrix
							// W[i][j] = 0 iff the entry dissimilarity F[i][j] is missing (unusable)
							// W[i][j] > 0 : weight or reliability of known F[i][j]
	private boolean[][] E; // E[i][j] = true iff W[i][j]>0 is known
	private ArrayList<ArrayList<Integer>> listW; // listW[i] is the set of nodes j such that W[i][j]>0;
	private double approx_error; // average distortion error for known dissimilarity
	
	MDS_Riemannian_Partial(double[][] F1, double[][] W1, int dim, double curvature) {
		if (curvature==0) {
			System.err.println("MDS_Riemannian_Partial(): curvature cannot be zero");
			System.exit(-1);
		}
		
		mds = (curvature>0)? new MDS_Sphere(dim, curvature):new MDS_Hyper(dim, curvature);
		mds.loadDissimMatrix(F1);
		n = mds.n;
		riemannian_dim = mds.riemannian_dim; // this is equal to m = (dim-1)
		
		W = MyMatrix.copy(W1);
		E = new boolean[n][n];
		
		listW = new ArrayList<ArrayList<Integer>>();
		for (int i=0; i<n; i++) {
			// list of points whose dissimilarity with i is known
			ArrayList<Integer> list_i = new ArrayList<Integer>();
			for (int j=0; j<n; j++) 
				if (W[i][j]>0 && i!=j && F1[i][j]>0) {
					// known and valid
					list_i.add(j);
					E[i][j]=true;
				}
			if (list_i.size() <=1) {
				System.err.println("MDS_Riemannian_Partial(): bad matrix W (node " + i + " has <=1 known values)");
				System.exit(-1);
			}
			listW.add(list_i);
		}
	}
	
	
	private void computeErrors() {
		approx_error = InputCommon.error(InputCommon.error_to_optimize, mds.F, mds.geodesic_dist, E);
	}
	
	void embed(int num_network_iterations, int num_node_iterations) {
		// an iterative algorithm	
		// initialization
		double[][] X = mds.randomPoint(n);
		
		// iterative algorithm to revise X
		for (int count=0; count < num_network_iterations; count++) {
			for (int i=0; i<n; i++) {
				// list of points whose dissimilarity with i is known
				ArrayList<Integer> list = listW.get(i);
				if (list.size() ==0) continue;
				
				double[][] y = new double[list.size()][riemannian_dim+1];
				double[] distances = new double[y.length];
				double[] weight = new double[y.length];
				
				for(int j1=0; j1<list.size(); j1++) {
					int j=list.get(j1);
					y[j1] = X[j];
					distances[j1] = mds.F[i][j];
					weight[j1] = W[i][j];
				}
				X[i] = mds.multilateration(X[i], y, distances, weight, num_node_iterations); // 10 is good
			}
//			double[] err = InputCommon.error(InputCommon.error_to_optimize, mds.F, mds.geodesic(X),E);
//			System.err.println(err[0] + "," + err[1]);
		}
		mds.X = X;
		mds.geodesic_dist = mds.geodesic(X);
	}
	
	static MDS_Riemannian_Partial bestMDS(	double[][] F, double[][] W, int m, 
											double[] curvature_range,	
											int num_network_iterations, int num_node_iterations) {
		//System.out.println(" find the best dimension, best curvature");
		MDS_Riemannian_Partial best_mds = null;
		double min = Double.MAX_VALUE;
		for (double k : curvature_range) {
			if (k!=0) { 
				System.out.println("dim=" + m + ", curvature= " + k);
				MDS_Riemannian_Partial mds = new MDS_Riemannian_Partial(F, W, m, k);
				mds.embed(num_network_iterations, num_node_iterations);
				mds.computeErrors();
				if (mds.approx_error < min) {
					min = mds.approx_error;
					best_mds = mds;
				}
				
			}				
		}
		System.out.println("dim " + m + ": best curvature= " + best_mds.mds.curvature);		
		return best_mds;
	}
}