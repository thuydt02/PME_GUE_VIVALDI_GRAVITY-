/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package run;

import common.Files;
import common.Matrices;
import common.dissimMatrix;


public class synDissimMatrix {
   
    public static void main(String[] args) throws Exception{
        int num_point  = 500;
        int dim = 2;
        double[] pnorm = {0.1, 0.9};
        String out_dir = "../data/lpnorm500/input/";
        for (int i = 0; i < pnorm.length; i++){
            
        
            double[][] dissimMat = dissimMatrix.genDissimMat(num_point, dim, pnorm[i]);
            double TIV= dissimMatrix.numTIV(dissimMat);
            String out_file = out_dir + "lpnorm" + String.format("%.1f",pnorm[i]) + 
                                       "tiv" + String.format("%.2f",TIV); 
            Files.saveFile(dissimMat, out_file);
            
        }
        
        
    }
}    
        
    //int num_point = 100;
        //int dim = 2;
        //double[] pnorm = {2.0};//{0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9};
        //String out_dir = "../data/logmpn05_normalized/input/";
        //String mass_dir = "../data/logmpn05_normalized/input/"; // normal distribution from normrnd(1,2,140,1); 
                               //after that take 100 positive number and save to the mass file
        
        //String mass_file= mass_dir + "lognorm_mass_miu0_sigma05";
        //int num_pnorm = pnorm.length;
        //String[] dissim_file = new String[num_pnorm];
        //double[][] dissimMat;
        
        //double[] mass ; //100
        //double[][] out = new double[num_point][num_point];
       
        //mass = Files.readCSVFile(mass_file);
        //mass = Matrices.normalizedVector(mass);
        //dissimMat = dissimMat = dissimMatrix.genDissimMat(num_point, dim, pnorm[0]);
        //double max1 = 0, max2 = 0;
        
        /*
        System.out.println("TIV pnorm 02: " + String.valueOf(dissimMatrix.numTIV(dissimMat)));
        for (int u = 0; u < num_point; u++)
                for (int v = 0; v < num_point; v++){
                    out[u][v] = mass[u] * mass[v] * dissimMat[u][v];
                    if (max1<dissimMat[u][v]) max1 = dissimMat[u][v];
                    if (max2<out[u][v]) max2 = out[u][v];
                }
            System.out.println("max distance: " + String.valueOf(max1));
            System.out.println("max dissim: " + String.valueOf(max2));
            dissim_file[0] = out_dir + "mpnorm20" + "N100___";
            Files.saveFile(out, dissim_file[0]);
            System.out.println("saved file: " + dissim_file[0]);
            double TIV= dissimMatrix.numTIV(out);
            System.out.println("TIV: " + String.valueOf(TIV));
        //mass = Matrices.normalizedVector(mass);
        /*
        for (int i = 0; i < num_pnorm; i++){
        {    
            
        //    mass_file = mass_dir + "mass" + String.valueOf((int)(pnorm[i] * 10)) + "N100";
            dissimMat = dissimMatrix.genDissimMat(num_point, dim, pnorm[i]);
            dissimMat = Matrices.normalizedMat(dissimMat);
            
            for (int u = 0; u < num_point; u++)
                for (int v = 0; v < num_point; v++){
                    out[u][v] = mass[u] * mass[v] * dissimMat[u][v];
                }
            
            dissim_file[i] = out_dir + "mpnorm" + String.valueOf((int)(pnorm[i] * 10)) + "N100";
            Files.saveFile(out, dissim_file[i]);
            System.out.println("saved file: " + dissim_file[i]);
        }
        
       //compute TIV
        double[] TIV = new double[num_pnorm];
        for (int i = 1; i <= num_pnorm; i++){
            String fname = out_dir + "mpnorm" + String.valueOf(i) + "N100";
            double[][] mat = Files.readFile(fname);
            TIV[i-1] = dissimMatrix.numTIV(mat);
        }
        
        Files.saveVectorFile(TIV, out_dir + "TIV");
       
     */  
   
        


        //to gen syn dissim matrices
        
        /*int num_point = 1000;
        int dim = 2;
        double[] pnorm = {1};//{0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9};
        String out_dir = "data/synDissimMat/input/";
        
        int num_pnorm = pnorm.length;
        String[] dissim_file = new String[num_pnorm];
        double[][] dissimMat;
        double TIV;
        for (int i = 0; i < num_pnorm; i++){
            
            dissimMat = dissimMatrix.genDissimMat(num_point, dim, pnorm[i]);
            TIV = dissimMatrix.numTIV(dissimMat);
            System.out.printf("%s%d%s%d%s%4.2f%s%6.4f","\nGenerating a dissim matrix with num point = ", num_point,
                              " dim = ", dim,
                              " pnorm = ", pnorm[i],
                              " TIV = ", TIV);
            
            dissim_file[i] = out_dir + "N" + String.valueOf(num_point) + 
                                       "D" + String.valueOf(dim) +
                                       "P" + String.format("%.1f",pnorm[i]) + 
                                       "TIV" + String.format("%.2f",TIV);
            Files.saveFile(dissimMat, dissim_file[i]);
            
        }
        */
   
