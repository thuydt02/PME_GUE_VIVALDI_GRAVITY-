/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
This package is to run gravity alg with vivaldi-embedding

*/

package gravity_vivaldi;
import common.ErrorType;
import common.Files;

public class Gravity_vivaldi {
    
    private static ErrorType optimize_err = ErrorType.RMSRE;  
    
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
    public Gravity_vivaldi(ErrorType opt_err){
        optimize_err = opt_err;
    }
    
    private static double[][] computeWeight(double[][] F, int[][] E){
        int n = F.length;
        double[][] W = new double[n][n];
        for (int i=0; i<n; i++)
            for (int j=0; j<i; j++) {
                if ((E[i][j] == 0) || (F[i][j] == 0)) continue;
                switch (optimize_err) {
                    case RMSRE:
                        W[i][j] = 1.0/(F[i][j]*F[i][j]);
                        break;
                    case RMSE:
                        W[i][j]=1.0;						
                        break;
                    default:
                        System.err.println("loadKnownMatrix(): error_to_optimize can only be rmsre or rmse");
                        System.exit(-1);
                }
                W[j][i]=W[i][j];
            }
        
        return W;
    }
    
    public static void gravityVivaldi(double[][] fnormMat, int[][] knownMat, 
                                            double[][] dist,
                                            double alpha,
                                            int num_iteration,
                                            String estimated_dissim_file
                                            ) throws Exception{
   
        //do gravity, but dont return error
        //fnormMat : the normalized F (dissimilarity matrix)
        //knownMat: the known matrix to train, and compute error
        //dim: dimension of the euclidean space you want to embed
        //dist: input distance matrix, this file is computed be PME
        //alpha: the power of distance in the embedding, should be > 1
        //estimated dissim_file : file name to save of the estmated dissimilarity matrix
        //num_iteration : number of iteration to compute mass
        int n = fnormMat.length;
        double[][] F_est = new double[n][n];
    
        double[] mass = computeMass(fnormMat, knownMat, dist, alpha, num_iteration);
        
        if (!"".equals(estimated_dissim_file)){
            
            for (int i = 0; i < n; i++)
                for (int j = 0; j < i; j++){
                    F_est[i][j] = mass[i] * mass[j] * Math.pow(dist[i][j], alpha);
                    F_est[j][i] = F_est[i][j];
                }
            Files.saveFile(F_est, estimated_dissim_file);
            
        }
        
        
     }
    private static double[] computeMass(double[][] F, int[][] E, double[][] dist, double alpha, int num_iteration) {
        //given a dissimilarity matrix F and a distance matrix dist
        //given a known matrix E
        //given alpha is the power of distance in the embedding
        // compute mass_i, mass_j such that F_ij = mass_i mass_j (dist_ij)^alpha
        int n = F.length;
        
        double[][] W = computeWeight(F,E);
        
        double[] mass = new double[n];

        for (int i=0; i<n; i++) mass[i] = 1;

        for (int gen=0; gen<num_iteration; gen++) {
                for (int i=0; i<n; i++) {
                    double sum_top = 0;
                    double sum_bottom = 0;						
                    for (int j=0; j<n; j++) {
                            if (F[i][j] <=0) continue;
                            if (E[i][j] == 1) {
                                    sum_top += W[i][j]*mass[j] * F[i][j] * Math.pow(dist[i][j], alpha);
                                    sum_bottom += W[i][j]*Math.pow(mass[j]*Math.pow(dist[i][j], alpha),2);
                            }
                    }
                    mass[i] = (sum_bottom>0)?sum_top /sum_bottom:1;
                }
        }

        return mass;
    }
    
}