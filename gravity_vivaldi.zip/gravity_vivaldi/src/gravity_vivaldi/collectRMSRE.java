/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gravity_vivaldi;

//this class is to collect error (RMSE and RMSRE from 100 runs)

import common.Files;

public class collectRMSRE {
    private static final String INPUT_DIR = "../data/king/output/gravity_vivaldi/RMSRE100/E20/";// "../data/synWTW/output/PME_vivaldi/RMSRE/E20/";
    private static final String OUTPUT_DIR = "../data/king/output/gravity_vivaldi/RMSRE100/E20/";// "../data/synWTW/output/PME_vivaldi/RMSRE/E20/";
    private static final int[] M = {3,5,7};//{2,3,5,7,9};
    
    
    public static void main(String[] args) throws Exception{
        String input_dir = "";
        String output_dir = "";
        int run_start = 0, run_end = 99;
        int m = 0;
        
        if (args.length == 5){
            input_dir = args[0];
            output_dir = args[1];
            run_start = Integer.parseInt(args[2]);
            run_end = Integer.parseInt(args[3]);
            m = Integer.parseInt(args[4]);
        }
        
        collect(input_dir, output_dir, run_start, run_end, m);
    }
    public static void collect(String input_dir, String output_dir, int run_start, int run_end, int m) throws Exception{
        //collect error from run_start to run_end,
        //output error file will be placed in output_dir
        //m = dimension, if m = -1 => collect all dimension
        
        if (input_dir.isEmpty()) input_dir = INPUT_DIR;
        if (output_dir.isEmpty()) output_dir = OUTPUT_DIR;
        int[] dim;
        
        if (m == 0) dim = M;
        else {
            dim = new int[] {m};
        }
        
        String run_dir;
        //String[] RMSE_train_fname = new String[dim.length];// output_dir + "RMSE_train_m";
        //String[] RMSE_test_fname = new String[dim.length];//output_dir + "RMSE_test_m";
        String[] RMSRE_train_fname = new String[dim.length];//output_dir + "RMSRE_train_m";
        String[] RMSRE_test_fname = new String[dim.length];//output_dir + "RMSRE_test_m";
        int d = 0;
        for (int one_m: dim){
          //  RMSE_train_fname[d] = output_dir + "RMSE_train_m" + String.valueOf(one_m) + "_run" + String.valueOf(run_start) + "_" + String.valueOf(run_end) + ".csv";
          //  RMSE_test_fname[d] = output_dir + "RMSE_test_m" + String.valueOf(one_m)+ "_run" + String.valueOf(run_start) + "_" + String.valueOf(run_end) + ".csv";
            RMSRE_train_fname[d] = output_dir + "RMSRE_train_m" + String.valueOf(one_m)+ "_run" + String.valueOf(run_start) + "_" + String.valueOf(run_end) + ".csv";
            RMSRE_test_fname[d] = output_dir + "RMSRE_test_m" + String.valueOf(one_m)+ "_run" + String.valueOf(run_start) + "_" + String.valueOf(run_end) + ".csv";
            d++;
        }
        
        
        //double[][] RMSE_train = new double[16][run_end - run_start + 1];
        //double[][] RMSE_test = new double[16][run_end - run_start + 1];
        double[][] RMSRE_train = new double[16][run_end - run_start + 1];
        double[][] RMSRE_test = new double[16][run_end - run_start + 1];
        
        d = 0;
        
        for (int one_m : dim){
            
        
            for (int run = run_start; run<= run_end; run++){
                run_dir = input_dir + "run" + String.valueOf(run) + "/";
          //      String rmse_fname_read = run_dir + "RMSE_m" + String.valueOf(one_m) + ".csv";
                String rmsre_fname_read = run_dir + "RMSRE_m" + String.valueOf(one_m) + ".csv";
         //       double[][] rmseMat = Files.readFile(rmse_fname_read, ",", true);
                double[][] rmsreMat = Files.readFile(rmsre_fname_read, ",", true);
                
                for (int row = 0; row < 16; row++ ){
           //         RMSE_train[row][run] = rmseMat[row][1];
           //         RMSE_test[row][run] = rmseMat[row][2];
                    RMSRE_train[row][run] = rmsreMat[row][1];
                    RMSRE_test[row][run] = rmsreMat[row][2];
                }
                
            }
            
          //  Files.saveFile(RMSE_train, RMSE_train_fname[d]);
          //  Files.saveFile(RMSE_test, RMSE_test_fname[d]);
            
            Files.saveFile(RMSRE_train, RMSRE_train_fname[d]);
            Files.saveFile(RMSRE_test, RMSRE_test_fname[d]);
            d++;
        }   
    }
    
    
}
