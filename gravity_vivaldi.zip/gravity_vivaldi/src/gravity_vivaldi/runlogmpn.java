package gravity_vivaldi;

import common.EmpiricalError;
import common.ErrorType;
import common.Files;
import common.Matrices;
import common.dissimMatrix;
import java.io.File;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author thuydt
 */

public class runlogmpn {
    
    private double [][] F;
    private boolean[][] avoided;
    
    private static final int num_iteration_mass = 100;
    private static final int[] dim = {3,5,7};
    
    private static final ErrorType et = ErrorType.RMSRE;//error to optimize
    
    private static final String base_in_dir = "../data/logmpn05_normalized/input/";

    private static final String dissim_file = "mpnorm20N100";
    private static final String pme_dist_dir = "../data/logmpn05_normalized/output/PME_vivaldi/"+ et.name() + "5000/mpnorm20N100/"; 
    private static final String output_dir = "../data/logmpn05_normalized/output/gravity_vivaldi/" + et.name()+ 
                                              String.valueOf(num_iteration_mass)+"/mpnorm20N100/";
    //you have to manually create the directory ../data/king/output/PME_vivaldi/"
    
    public static void main(String[] args) throws Exception{
        String e_file = "E20";
        int run_start = 0;
        int run_end = 99;
        ErrorType[] err = {ErrorType.RMSRE};
        
        if (args.length == 3){
            e_file = args[0];
            run_start = Integer.parseInt(args[1]);
            run_end = Integer.parseInt(args[2]);
        }
        
        runlogmpn prun = new runlogmpn();
       // prun.run(e_file, run_start, run_end);
        prun.error(e_file, run_start, run_end, err);       
    }
    
    public void init_F() throws Exception{
        
        F = Files.readFile(base_in_dir + dissim_file); 
        if (F == null) {System.err.print("The input matrix F is null!"); exit(0);}    
    } 
    
    public void init_avoided() throws Exception{
        if (F == null) init_F();
        int n = F.length;
        avoided = new boolean[n][n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++){
                avoided[i][j] = (F[i][j] <= 0);
            }
        
    }
    
    
    public void run(String e_file, int run_start, int run_end) throws Exception{
   
        String known_file = base_in_dir + "E/" + e_file + "N100";

        //for output
        String sub_output_dir = output_dir + e_file + "/";
        String sub_pme_dist_dir = pme_dist_dir + e_file + "/";

        new File(output_dir).mkdir();
        new File(sub_output_dir).mkdir();
        

        double[] alpha = {1, 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9, 2.0, 2.1, 2.2, 2.3, 2.4, 2.5};//, 2.6, 2.7, 2.8, 2.9, 3}        
        int height = 0;

        
        String distance_file;
        String dissim_est_file;
        
        String run_dir;
        String alp_dir;
        
        String pme_run_dir;
        String pme_alp_dir;
        
        int num_dim = dim.length;
        int num_alp = alpha.length;

        init_F();

        System.out.println("Initilized F file " + base_in_dir + dissim_file);
        System.out.println("TIV: " + dissimMatrix.numTIV(F));
        double[][] dist;
        
        int[][] known;// known matrix

        for (int run = run_start; run <= run_end; run++){

            run_dir = sub_output_dir + "run" + String.valueOf(run) + "/";
            new File(run_dir).mkdir();

            known = Files.readIntFile(known_file + "_run" + String.valueOf(run));
            System.out.println("initilized known file " + known_file +"_run" + String.valueOf(run));

            for (double alp : alpha){

                alp_dir = sub_output_dir + "run" + String.valueOf(run) + "/alpha_" + String.valueOf(alp) + "/";
                pme_alp_dir = sub_pme_dist_dir + "run" + String.valueOf(run) + "/alpha_" + String.valueOf(alp) + "/";
                
                new File(alp_dir).mkdir();

                for (int m : dim){

                    distance_file = pme_alp_dir + "m" + String.valueOf(m) + ".dist.csv";
                    
                    dissim_est_file = alp_dir + "m" + String.valueOf(m) + ".dissim.csv";
                    
                    dist = Files.readFile(distance_file);
                    System.out.println("read distance file: " + distance_file);
                    
                    Gravity_vivaldi.gravityVivaldi(F, known, dist, alp, num_iteration_mass, 
                                   dissim_est_file);

                    System.out.println("saved estimated dissimilarity file: " + dissim_est_file);
                    
                }
            }
        } 
  }
    
  public void error(String e_file, int run_start, int run_end, ErrorType[] err) throws Exception{
            
        String known_file = base_in_dir + "E/" + e_file + "N100";

        //for output
        String sub_output_dir = output_dir + e_file + "/";
        String run_dir;
        String alp_dir;

        double[] alpha = {1, 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9, 2.0, 2.1, 2.2, 2.3, 2.4, 2.5};//, 2.6, 2.7, 2.8, 2.9, 3}        

        String dissim_est_file;
        int num_dim = dim.length;
        int num_alp = alpha.length;

        if (F == null) {
            init_F();
            System.out.println("Initilized F file " + base_in_dir + dissim_file);
        }
        
        System.out.println("TIV F: " + dissimMatrix.numTIV(F));
        
        if (avoided == null) {
            init_avoided();
        }
        double[][] known;
        
        for (int run = run_start; run <= run_end; run++){

            run_dir = sub_output_dir + "run" + String.valueOf(run) + "/";

            known = Files.readFile(known_file + "_run" + String.valueOf(run));
            System.out.println("initilized known file " + known_file + "_run" + String.valueOf(run));

            for (double alp : alpha){

                alp_dir = sub_output_dir + "run" + String.valueOf(run) + "/alpha_" + String.valueOf(alp) + "/";
                
                for (ErrorType rp_et: err){

                    double[][] each_alp_errMat = new double[num_dim][3];
                    int row = 0;
                    for (int m : dim){
                        dissim_est_file = alp_dir + "m" + String.valueOf(m) + ".dissim.csv";

                        double[][] estimated = Files.readFile(dissim_est_file);
                      //  estimated = Matrices.powMat(estimated, alp);

                        double [] error = report_error(rp_et, F, estimated, known, avoided);
                        double[] tmp = {m, error[0], error[1]};
                        each_alp_errMat[row] = tmp;

                        row += 1;
                    }
                    String each_alp_error_file = alp_dir + rp_et.name() + ".csv";
                    String header = "m,train,test";

                    Files.saveFile(each_alp_errMat, header, each_alp_error_file);
                    System.out.println("saved file: " + each_alp_error_file);
                }
            }
        }
    
//compute error on each m and the range of alp
   
       for (int run = run_start; run <= run_end; run++){
       
            init_avoided();
            run_dir = sub_output_dir + "run" + String.valueOf(run) + "/";

            known = Files.readFile(known_file + "_run" + String.valueOf(run));
            System.out.println("initilized known file " + known_file + "_run" + String.valueOf(run));

            for (int m : dim){
                for (ErrorType rp_et: err){

                    double[][] each_m_errMat = new double[num_alp][3];

                    int alp_ind = 0;

                    for (double alp: alpha){

                        String estimated_file = run_dir + "alpha_" + String.valueOf(alp) + "/m" + String.valueOf(m) + ".dissim.csv";
                        double[][] estimated = Files.readFile(estimated_file);
                    //    estimated = Matrices.powMat(estimated, alp);

                        double[] error = report_error(rp_et,F, estimated, known, avoided);
                        double[] tmp = {alp, error[0], error[1]} ;
                        each_m_errMat[alp_ind]  = tmp;

                        alp_ind += 1;
                    }
                    String each_m_error_file = run_dir + rp_et.name() + "_m" + String.valueOf(m) + ".csv";
                    String header = "alp,train,test";
                    Files.saveFile(each_m_errMat, header, each_m_error_file);

                    System.out.println("saved file: " + each_m_error_file);
                }
            }
       }         
  }


    
  
  private double[] report_error(ErrorType et, double[][] actual, double[][] estimated, double[][] known, boolean[][] avoided) throws Exception  {
    if (null != et)
            switch (et) {
             case MRE:
                 return EmpiricalError.error_RelativeMean_Symmetric(actual, estimated, known, avoided);
             case RMSRE:
                 return EmpiricalError.RMSRE(actual, estimated, known, avoided);
             case RMSE:
                 return EmpiricalError.RMSE(actual, estimated, known, avoided);
             default:
                 break;
         }
        return new double[] {0,0};
}
    
    
    private void exit(int i) {
        throw new UnsupportedOperationException("The F file is NULL!."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
