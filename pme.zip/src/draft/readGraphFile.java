/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package draft;
import common.Files;

/**
 *
 * @author thuydt
 */
public class readGraphFile {
     
    public static double[][] weightReadFile(String f_name, String delimiter) throws Exception{
        
        if (f_name.equals("")) {
            System.out.println("common.Graph.readFile(): cannot read a file with an empty f_name");
            return null;
        }
        
        double[][] gmat = Files.readFile(f_name, delimiter);
    
        if (gmat == null) return null;
        
        
        int num_node = 113; // node index from 0
        double [][] A = new double[num_node][num_node];
        
        int num_row  = gmat.length;
        for (int k = 0; k < num_row; k++){
            int i = (int)gmat[k][0]; int j = (int)gmat[k][1];
            A[i-1][j-1] += gmat[k][2];
        }
        for (int i = 0; i < 113; i++)
            for (int j = 0; j < i; j++)
            {
                if (A[i][j] > 0) A[j][i] = A[i][j];
                else
                    A[i][j] = A[j][i];
            }
        return A;
    }

    public static void main(String[] args) throws Exception{
        String f_name = "../data/sociopatterns-hypertext/input/out.sociopatterns-hypertext";
        String out_file = "../data/sociopatterns-hypertext/input/out.sociopatterns-hypertext.csv";
        double[][] A = weightReadFile(f_name, " ");
        Files.saveFile(A, out_file);
        
    }
}
