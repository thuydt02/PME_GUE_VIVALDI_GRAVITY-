/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pme;

import centralizedvivaldi.cVivaldi;
import common.EmpiricalError;
import common.tFile;
import common.Matrices;
import common.ErrorType;

public class PME {
   
    
    public static double[] PMEVivaldi(double[][] fnormMat, double[][] knownMat, 
                                            int dim, int height, int num_iteration,
                                            String distance_file,
                                            String init_coord_file, String out_coord_file, 
                                            double alp_PME, ErrorType et) throws Exception{
   
        //do pme
        //fnormMat : the normalized F (dissimilarity matrix)
        //knownMat: the known matrix to train, and compute error
        //dim: dimension of the euclidean space you want to embed
        //height = 0 => without hieght; 1 otherwise, pls come to the origin paper for what is height
        //distance_file: the file name of the output distance file, if you dont want to save the file => set to ""
        //init_coord_file: the file name of initial coordinates (csv format), 
        //if no height => each column is for each dimension
        //if with height => the last column if for height, the rest columns are for dimensions as no height
        //out_coord_file file name of the output coordinate file, if you dont want to save the coordinate file => set to ""
        //alp_PME: the power of PME, should be > 1
        //et: error type you want to report, actually you should use RMSRE or MRE because the vivaldi function obtimize on relative error
        
        cVivaldi cv = new cVivaldi();
        
        double[][] G = Matrices.powMat(fnormMat, 1.0/alp_PME);
        
        double[][] Ghat = cv.vivaldiMat(G, knownMat, 
                                        dim, height, num_iteration, 
                                        init_coord_file, out_coord_file);
        
        double[][] H = Matrices.powMat(Ghat, alp_PME);
        
        if (!distance_file.isEmpty()){
            tFile.saveFile(Ghat, distance_file); //
        }
        
        if (null != et)
            switch (et) {
             case MRE:
                 return EmpiricalError.error_RelativeMean_Symmetric(fnormMat, H, knownMat);
             case RMSRE:
                 return EmpiricalError.RMSRE(fnormMat, H, knownMat);
             case RMSE:
                 return EmpiricalError.RMSE(fnormMat, H, knownMat);
             default:
                 break;
         }
        return new double[] {0,0};
     }
    
    public static double[] PMEVivaldi(double[][] fnormMat, double[][] knownMat, 
                                            int dim, int height, int num_iteration,
                                            String distance_file,
                                            String init_coord_file, String out_coord_file, 
                                            double alp_PME, ErrorType et, boolean[][] avoided) throws Exception{
       //same as the function before, added avoided
        cVivaldi cv = new cVivaldi();
        
        double[][] G = Matrices.powMat(fnormMat, 1.0/alp_PME);
        
        double[][] Ghat = cv.vivaldiMat(G, knownMat, 
                                        dim, height, num_iteration, 
                                        init_coord_file, out_coord_file);
        
        double[][] H = Matrices.powMat(Ghat, alp_PME);
        
        if (!distance_file.isEmpty()){
            tFile.saveFile(Ghat, distance_file); //
        }
        
        if (null != et)
            switch (et) {
             case MRE:
                 return EmpiricalError.error_RelativeMean_Symmetric(fnormMat, H, knownMat, avoided);
             case RMSRE:
                 return EmpiricalError.RMSRE(fnormMat, H, knownMat, avoided);
             case RMSE:
                 return EmpiricalError.RMSE(fnormMat, H, knownMat, avoided);
             default:
                 break;
         }
        return new double[] {0,0};
     }
    
    
    public static void PMEVivaldi(double[][] fnormMat, double[][] knownMat, 
                                            int dim, int height, int num_iteration,
                                            String distance_file,
                                            String init_coord_file, String out_coord_file, 
                                            double alp_PME) throws Exception{
   
        //do pme, but dont return error
        //fnormMat : the normalized F (dissimilarity matrix)
        //knownMat: the known matrix to train, and compute error
        //dim: dimension of the euclidean space you want to embed
        //height = 0 => without hieght; 1 otherwise, pls come to the origin paper for what is height
        //distance_file: the file name of the output distance file, if you dont want to save the file => set to ""
        //init_coord_file: the file name of initial coordinates (csv format), 
        //if no height => each column is for each dimension
        //if with height => the last column if for height, the rest columns are for dimensions as no height
        //out_coord_file file name of the output coordinate file, if you dont want to save the coordinate file => set to ""
        //alp_PME: the power of PME, should be > 1
        //et: error type you want to report, actually you should use RMSRE or MRE because the vivaldi function obtimize on relative error
        
        cVivaldi cv = new cVivaldi();
        
        double[][] G = Matrices.powMat(fnormMat, 1.0/alp_PME);
        
        double[][] Ghat = cv.vivaldiMat(G, knownMat, 
                                        dim, height, num_iteration, 
                                        init_coord_file, out_coord_file);
        
        double[][] H = Matrices.powMat(Ghat, alp_PME);
        
        if (!distance_file.isEmpty()){
            tFile.saveFile(Ghat, distance_file); //
        }
     }
    
}
