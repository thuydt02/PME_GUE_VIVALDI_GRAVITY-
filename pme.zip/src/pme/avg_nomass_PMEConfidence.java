/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pme;

// this class is dedicated to compute mean, stdevA, margin error of the dataset synDissimMat pnorm = .1 -> .9

import common.Files;

public class avg_nomass_PMEConfidence {
    
    private static final double[] zs = {1.282, 1.44, 1.645, 1.96,2.576,2.807,3.291};
    private static final double[] confid_intervals = {0.8, 0.85, 0.9, 0.95, 0.99, 0.995, 0.999};
    

    public static void computeConfid(String in_file, String out_file, double confid_interval) throws Exception {
        //in_file : the structure is like nomass_train_m3
        //out_file: mean (col1), stdevA (col2), margin error (col3), pme_alp/pme_alp1 (col4, col5, ...)
        //confid_interval = 90% for example =>0.9 
        
        double[][] in_mat = Files.readFile(in_file);
        int num_row = in_mat.length;
        int num_col = in_mat[0].length;
        
        double[][] out_mat = new double[num_row][num_col + 3];
        
        
       
//looking for the z, given confid_level
        int num_z = zs.length;
        double z = 0;
        for (int i = 0; i< num_z; i++){
            
            if (confid_intervals[i] == confid_interval){ 
                z = zs[i]; break;
            }
            if (confid_intervals[i] > confid_interval) break;
        }
        
        if (z == 0){
            System.out.println("latest.PMEConfidence.computeConfid(): cannot find the z for the confidence interval: "
                    + String.valueOf(confid_intervals));
            return;
        }
//change the in_mat by pme_alp/pme_alp1
      /*  for (int i = 1; i < num_row; i ++)
            for (int j = 0; j < num_col; j++)
                in_mat[i][j] = in_mat[i][j] / in_mat[0][j]; // not handle the case in_mat[0][j] == 0
        
        for (int j = 0; j < num_col; j++)
            in_mat[0][j] = 1;
      */  
        double[] mean = new double[num_row]; 
        double stdevA, margin_error;
        
        for (int i = 0; i< num_row; i++){
            mean[i] = 0;
            for (int j = 0; j < num_col; j++){
                mean[i] += in_mat[i][j];
            }
            mean[i] = mean[i] / (double)num_col;
        }
        
        for (int i = 0; i < num_row; i++){
            
            stdevA = 0;
            for (int j = 0; j < num_col; j++){
                stdevA += Math.pow(in_mat[i][j] - mean[i], 2);
                out_mat[i][3+j] = in_mat[i][j];
            }
            stdevA = Math.sqrt(stdevA/(double) (num_col));
            margin_error = z * stdevA / Math.sqrt(num_col);
            
            out_mat[i][0] = mean[i];
            out_mat[i][1] = stdevA;
            out_mat[i][2] = margin_error;
        }
        Files.saveFile(out_mat, out_file);
    }
    
    public static void computeMarginError(String input_dir, String output_dir) throws Exception{
        String[] m = {"3","5","7","9"};
        int num_m = m.length;
        double confid_interval = 0.999;
        String in_file, out_file;
        String INPUT_DIR = "../data/synWTW/output/PME_vivaldi/RMSRE/E20/";
        String OUTPUT_DIR = "../data/synWTW/output/PME_vivaldi/RMSRE/E20/";
        
        if (!input_dir.isEmpty()) INPUT_DIR = input_dir;
        if (!output_dir.isEmpty()) OUTPUT_DIR = output_dir;
        
        //String base_in_dir = "data/king/rmsre/E60/";
        
            for (int d = 0; d < num_m; d++){
                
               // in_file = INPUT_DIR + "RMSE_train_m" + m[d] + ".csv";
               // out_file = OUTPUT_DIR + "avg_RMSE_train_m" + m[d] + "_run0_99";
               // computeConfid(in_file, out_file, confid_interval);
                
              //  in_file = INPUT_DIR + "RMSE_test_m" + m[d] + ".csv";
              //  out_file = OUTPUT_DIR + "avg_RMSE_test_m" + m[d] + "_run0_99";
              //  computeConfid(in_file, out_file, confid_interval);
                
                in_file = INPUT_DIR + "nomass_train_m" + m[d] + ".csv";
                out_file = OUTPUT_DIR + "avg_RMSRE_nomass_train_m" + m[d] + "_run0_99";
                computeConfid(in_file, out_file, confid_interval);
                
                in_file = INPUT_DIR + "nomass_test_m" + m[d] + ".csv";
                out_file = OUTPUT_DIR + "avg_RMSRE_nomass_test_m" + m[d] + "_run0_99";
                computeConfid(in_file, out_file, confid_interval);
            }
        
        
    }
    
    public static void main(String[] args) throws Exception{
        
        String input_dir = "../gravity/data/king/rmsre/E20/";//"../data/synWTW/output/PME_vivaldi/RMSRE/E60/";//"../data/synWTW/output/PME_vivaldi/RMSRE/E20/";
        String output_dir = "../gravity/data/king/rmsre/E20/";//"../data/synWTW/output/PME_vivaldi/RMSRE/E60/";//"../data/synWTW/output/PME_vivaldi/RMSRE/E20/";
        computeMarginError(input_dir, output_dir);
    }
}
