/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pme;

import vivaldi.HeightCoordinate;
import vivaldi.vivaldiPosition;
import common.*;
//import java.util.Arrays;
public class runwithoutPME {
	public static double[][] vivaldiMat(double[][] fnormMat, double[][] knownMat, int num_iteration, int dim, int height){
		
		if ((fnormMat == null) || (knownMat == null)) return null;
		
		int N = fnormMat.length;
		if (N != fnormMat[0].length) return null;
		
		if (N != knownMat.length) return null;
		if (N != knownMat[0].length) return null;
		
		//randomly create points in dim dimensions, each point is HeightCoordinate
		
		double[] a_random = new double[dim];
		vivaldiPosition[] A = new vivaldiPosition[N];
		
		for (int i = 0; i < N; i++)
		{
			for (int j = 0; j < dim; j++) a_random[j] = Math.random();
			//System.out.println(Arrays.toString(a_random));
			HeightCoordinate hc = new HeightCoordinate(a_random, Math.random() * height);
			A[i] = new vivaldiPosition(hc);
			
		}
		
		double[][] F = Matrices.dotProduct(fnormMat, knownMat);
		
		for (int k = 0; k < num_iteration; k++) {
			for (int i = 0; i < N; i++){
                    
                            //System.out.println("before: "+ Arrays.toString(A[i].hCoordinate.v));
					
                        
			for (int j = 0; j < N; j++)
				if (i != j) {
					A[i].update(F[i][j], A[j]);
				}
                        
                        //System.out.println("after updated: " + Arrays.toString(A[i].hCoordinate.v));
		}
                }
		double[][] Fhat = new double[N][N] ;
		for (int i = 0; i < N; i++)
		for (int j = 0; j < i; j++) {
			Fhat[i][j] = A[i].hCoordinate.distance(A[j].hCoordinate);
			Fhat[j][i] = Fhat[i][j];
		}	
                
		return Fhat;
	}
    public static void pureVivaldi(String fnorm_file, String known_file, String fhat_file, int num_iteration, int dim, int height) throws Exception {         
        //int num_iteration = 1700;   
        //int dim = 3;
  
        double[][] fnormMat = Files.readFile(fnorm_file);
        if (fnormMat == null) return;
        
        double[][] knownMat = Files.readFile(known_file);
        if (knownMat == null) return;
        
        double[][] fhatMat = vivaldiMat(fnormMat, knownMat, num_iteration, dim, height);
        
        Files.saveFile(fhatMat, fhat_file);   
    }
	
	public static void runPlanetlab() throws Exception {
            int num_iteration = 1000;
            int dim = 4;
            int height = 0; // or 1 = with height
            
            String data_base_folder = "./data/planetlab/Input/";
            String out_base_folder = "./data/planetlab/vivaldi_output/";

            String[] known_file = {"w20n490","w40n490","w60n490","w80n490"};
            String[] fhat_file = {"fhat_w20n490m3","fhat_w40n490m5i1500","fhat_w60n490m2","fhat_w80n490m2"};
            double[] w = {20, 40, 60, 80};

            String fnorm_file = "PlanetLabData_1_Norm.csv";

            int num_known = known_file.length;
            num_known = 1;

            for (int i = 0; i < num_known; i++)
               pureVivaldi(data_base_folder + fnorm_file, 
                       data_base_folder+known_file[i], 
                       out_base_folder+fhat_file[i],
                       num_iteration, dim, height);


            double[][] rmse = new double[num_known][2];
            double[][] mre = new double[num_known][2];
            double[][] errorMat = new double[num_known][5];

            double[][] actualMat = Files.readFile(data_base_folder + fnorm_file);

            for (int i = 0; i < num_known; i++) {

                        double[][] predictedMat = Files.readFile(out_base_folder + fhat_file[i]);
                        double[][] knownMat = Files.readFile(data_base_folder + known_file[i]);

                        rmse[i] = EmpiricalError.RMSE(actualMat, predictedMat, knownMat);
                        mre[i] = EmpiricalError.error_RelativeMean_Symmetric(actualMat, predictedMat, knownMat);

                        errorMat[i][0] = w[i]; 
                        errorMat[i][1] = rmse[i][0]; errorMat[i][2] = rmse[i][1];
                        errorMat[i][3] = mre[i][0]; errorMat[i][4] = mre[i][1];
                }

                String error_file = out_base_folder + "rmse_mre_w20m3ce3i1700cc75.csv";
                Files.saveFile(errorMat, error_file);
	}
	
        public static void runKing363() throws Exception{    
        int num_iteration = 1000;
        int dim = 9;
        int height = 0;
        
        String in_base_folder = "./data/King363/input/";
        String out_base_folder = "./data/King363/vivaldi_output/";
        //String original_f_file = input_folder + "KingData_363.csv";

        // normalize the original files
        /*
        double[][] f = File.readFile(original_f_file);
        if (f== null) return;
        f = Matrix.replaceMat(f, -1, 0);String[] fhat_file = {"fhat_w20n363","fhat_w40n363","fhat_w60n363","fhat_w80n363","fhat_w100n363","fhat_w_short","fhat_w_long"};     

        f = Matrix.normalizedMat(f);
        String fnorm_file = input_folder + "KingData_363_Norm.csv";
        File.saveFile(f, f_file);
        */
        // end of normalization
        
        String fnorm_file = "KingData_363_Norm.csv";
        
        String[] known_file = {"w20n363","w40n363","w60n363","w80n363","w100n363","w_short","w_long"};                
        String[] fhat_file = {"fhat_w20n363m9","fhat_w40n363m9","fhat_w60n363m9","fhat_w80n363m9","fhat_w100n363m9","fhat_w_shortm9","fhat_w_longm9"};     
        double[] w = {20,40,60,80,100,1,-1};
        
        int num_known = known_file.length;        
        //num_known = 1;

        for (int i = 0; i < num_known; i++)
               pureVivaldi(in_base_folder + fnorm_file, 
                       in_base_folder+known_file[i], 
                       out_base_folder+fhat_file[i],
                       num_iteration, dim, height);        
        
        String original_f_file = "KingData_363.csv";
        
        double[][] F = Files.readFile(in_base_folder + original_f_file);
        if (F == null) return;
        
        double[][] avoided = Matrices.getPosition(F, -1); F = null;        
        if (avoided == null) return;
        
        double[][] rmse = new double[num_known][2];
        double[][] mre = new double[num_known][2];
        double[][] errorMat = new double[num_known][5];

        double[][] actualMat = Files.readFile(in_base_folder + fnorm_file);

        for (int i = 0; i < num_known; i++) {

            double[][] predictedMat = Files.readFile(out_base_folder + fhat_file[i]);
            double[][] knownMat = Files.readFile(in_base_folder + known_file[i]);

            rmse[i] = EmpiricalError.RMSE(actualMat, predictedMat, knownMat,avoided);
            mre[i] = EmpiricalError.error_RelativeMean_Symmetric(actualMat, predictedMat, knownMat,avoided);

            errorMat[i][0] = w[i]; 
            errorMat[i][1] = rmse[i][0]; errorMat[i][2] = rmse[i][1];
            errorMat[i][3] = mre[i][0]; errorMat[i][4] = mre[i][1];
            }

            String error_file = out_base_folder + "rmse_mre_m9.csv";
            Files.saveFile(errorMat, error_file);         
    }
        
        
        
        
        
        
	public static void main(String[] args) throws Exception {
		//runPlanetlab();
                runKing363();
                System.out.println("done !");
	}
}
