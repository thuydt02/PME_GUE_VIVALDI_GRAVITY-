package pmegue;

public class DissimEstimate extends InputCommon {
	// reconstruct dissimilarity matrix from a small set of known dissimilarity measurements
	
	boolean[][] E; // known matrix; E[i][j]=true means F[i][j] is known and usable (F[i][j]>0). 
	double[][] W; 	// non-negative weight matrix, W[i][j] is the reliability on F[i][j]; 0 if E_ij = false
	
	
	DissimEstimate(String dissim_filename, String known_filename) {
		loadDissimMatrix(dissim_filename);
		loadKnownMatrix(known_filename);
	}
	
	void loadKnownMatrix(String filename) {
		if (!Misc.isConnectedGraph(MyMatrix.loadFromFile_Int(filename))) {
			System.err.println("matrix E should form a connected graph");
			System.exit(-1);
		}
		
		E = MyMatrix.loadFromFile_Boolean(filename);
		
		// compute weights
		int num_known=0;
		W = new double[n][n];
		for (int i=0; i<n; i++)
			for (int j=0; j<i; j++) {
				if (!E[i][j]) continue;
				if (F[i][j]==0) {
					// NOTE: if F[i][j]=0, then it is considered not usable; should be ignored
					E[i][j]=false; 
					E[j][i]=false;
				}
				else {
					num_known++;
					if (error_to_optimize.equals("rmsre")) W[i][j] = 1.0/(F[i][j]*F[i][j]); 
					else if  (error_to_optimize.equals("rmse")) W[i][j]=1.0;
					else {
						System.err.println("loadKnownMatrix(): error_to_optimize can only be rmsre or rmse");
						System.exit(-1);
					}						
					W[j][i]=W[i][j];
				}		
			}
		System.out.println("% dissimilary known: " + 100*(double) num_known / (double) (n*(n-1)/2));
		
		// check for triangle inequality violation
		int num_tiv = 0;
		int num_triangle = 0;
		for (int i=0; i<n; i++)
			for (int j=0; j<i; j++) {
				if (!E[i][j]) continue;
				for (int k=0; k<j; k++) {
					if (E[i][k] && E[j][k]) {
						num_triangle++;
						// for a triple (i, j, k) there can only be at most 1 Triangle Inequality violation
						double a = F[i][j];
						double b = F[j][k];
						double c = F[k][i];
						if (a+b < c  || a+c < b || b+c < a) num_tiv++;
					}					
				}
			}
		if (num_triangle!=0)
			System.out.println("TIV of partial F = "+ 100.0*(double) num_tiv/(double) (num_triangle));
		else
			System.out.println("TIV of partial F = N/A (no triangle formed by known values)");
	}
	
	void run_Embedding(String space, int dim, 
			String position_out_file, 
			String dist_out_file,
			String dissim_out_file) {
		double[][] X1=null;
		double[][] dist1=null;
		if (space.equals("euclidean")) {
			MDS_Euclidean_Partial e_mds = new MDS_Euclidean_Partial(F, W);
			e_mds.embed(dim, num_network_iterations, num_node_iterations);
			X1 = e_mds.X;
			dist1 = e_mds.dist;
		}
		else if (space.equals("sphere")) {
			MDS_Riemannian_Partial r_mds = MDS_Riemannian_Partial.bestMDS(F, W, dim, curvature_range_sphere, 
					num_network_iterations, num_node_iterations);
			X1 = r_mds.mds.X;
			dist1 = r_mds.mds.geodesic_dist;
		}
		else if (space.equals("hyper")) {
			MDS_Riemannian_Partial r_mds = MDS_Riemannian_Partial.bestMDS(F, W, dim, curvature_range_hyper, 
					num_network_iterations, num_node_iterations);
			X1 = r_mds.mds.X;
			dist1 = r_mds.mds.geodesic_dist;
		}
		else {
			System.err.println("run_Embedding(): Embedding space not defined");
			System.exit(-1);
		}
		MyMatrix.saveAs(X1, position_out_file);
		MyMatrix.saveAs(dist1, dist_out_file);	
		MyMatrix.saveAs(dist1, dissim_out_file);	
	}
	
}