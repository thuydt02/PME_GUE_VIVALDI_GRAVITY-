package pmegue;

public class DissimEstimateGvity extends DissimEstimate {
	// reconstruct dissimilarity matrix from a small set of known dissimilarity measurements
	// using gravity model: f_ij = mass_i mass_j (d_ij)^alpha where d_ij is the underlying metric
	
	double alpha; // if alpha==1, TestDissimReconstructGravityModel works same as TestDissimReconstruct
	// must be >=1 
	// because otherwise, d_ij^alpha remains a metric, and instead of finding d_ij such that
	// d_ij^alpha ~ F, we find h_ij ~ F, and use h_ij instead of d_ij^alpha
	
	//double[] mass; // mass_i
	
	// estimated dissim matrix
	//double[][] F_est, 
        double[][] F_est_no_mass;
		
	// for convenience
	private double[][] F_alpha;
	
	DissimEstimateGvity(String dissim_filename, String known_filename) {
		super(dissim_filename, known_filename);
	}
	
	void setAlpha(double alpha1) {
		alpha = alpha1;
		F_alpha = new double[n][n];
		for (int i=0; i<n; i++)
			for (int j=0; j<i; j++) {
				if (F[i][j]==0) continue;
				F_alpha[i][j] = Math.pow(F[i][j], 1/alpha);
				F_alpha[j][i] = F_alpha[i][j];
			}
		// because F < 1 => F_alpha must be <1 => no need to normalize
		//System.out.println("F_alpha max = " + MyMatrix.max(F_alpha));		
	}	
	

	void completeDissimMatrix(double[][] dist) {
		// compute mass_i, mass_j such that F_ij = mass_i mass_j (dist_ij)^alpha
		/*
                mass = new double[n];
		for (int i=0; i<n; i++) mass[i] = 1;
		
		for (int gen=0; gen<100; gen++) {
			for (int i=0; i<n; i++) {
				double sum_top = 0;
				double sum_bottom = 0;						
				for (int j=0; j<n; j++) {
					if (E[i][j]) {
						sum_top += W[i][j]*mass[j] * F[i][j] * Math.pow(dist[i][j], alpha);
						sum_bottom += W[i][j]*Math.pow(mass[j]*Math.pow(dist[i][j], alpha),2);
					}
				}
				mass[i] = (sum_bottom>0)?sum_top /sum_bottom:1;
			}
		}
		
		F_est = new double[n][n];
		*/
                F_est_no_mass = new double[n][n];
		for (int i=0; i<n; i++)
			for (int j=0; j<i; j++) {
				if (F[i][j]>0) {
					F_est_no_mass[i][j] = Math.pow(dist[i][j], alpha);
				//	F_est[i][j] = mass[i]*mass[j]*F_est_no_mass[i][j];
				//	F_est[j][i] = F_est[i][j];
					F_est_no_mass[j][i] = F_est_no_mass[i][j];
				}
			}
	}
	
	void run_Embedding(String space, int dim, 
			String position_out_file, 
			String dist_out_file, 
			//String mass_out_file,
			//String dissim_out_file,
			String dissim_nomass_out_file) {
		
		double[][] X1=null;
		double[][] dist1=null;
		
		if (space.equals("euclidean")) {
			MDS_Euclidean_Partial e_mds = new MDS_Euclidean_Partial(F_alpha, W);
			e_mds.embed(dim, num_network_iterations, num_node_iterations);
			X1 = e_mds.X;
			dist1 = e_mds.dist;
		}
		else if (space.equals("sphere")) {
			MDS_Riemannian_Partial r_mds = MDS_Riemannian_Partial.bestMDS(F_alpha, W, dim, curvature_range_sphere, 
					num_network_iterations, num_node_iterations);
			X1 = r_mds.mds.X;
			dist1 = r_mds.mds.geodesic_dist;
		}
		else if (space.equals("hyper")) {
			MDS_Riemannian_Partial r_mds = MDS_Riemannian_Partial.bestMDS(F_alpha, W, dim, curvature_range_hyper, 
					num_network_iterations, num_node_iterations);
			X1 = r_mds.mds.X;
			dist1 = r_mds.mds.geodesic_dist;
		}
		else {
			System.err.println("run_Embedding(): Embedding space not defined");
			System.exit(-1);
		}
		
		MyMatrix.saveAs(X1, position_out_file);
		MyMatrix.saveAs(dist1, dist_out_file);		
		
		completeDissimMatrix(dist1);
		//MyMatrix.saveAs(mass, mass_out_file);
		//MyMatrix.saveAs(F_est, dissim_out_file);
		MyMatrix.saveAs(F_est_no_mass, dissim_nomass_out_file);
	}
	
}