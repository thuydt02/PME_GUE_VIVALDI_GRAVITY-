package pmegue;

public class InputCommon {
	// constraints for embedding dimension
	static int[] dim_range = {3,5,7};//{2,3,5,7,9};
			
	// max and min for surface curvature
	// for spherical embedding, 
	// since max(dissim) = 1, Pi*Radius must be at least 1 to have enough space for F
	// equivalently, Pi*1/sqrt(curvature) > 1 <=> curvature < Pi^2
	
	static double curvature_range_sphere[] = {1, 2, 3, 4, 5, 6, 7, 8, 9}; //max = Math.PI*Math.PI-0.1; 
	static double curvature_range_hyper[] = {-1, -2, -3, -4, -5, -6, -7, -8, -9}; // min = no limit
	
	/* 	num of iterations for greedy algorithm (make sure to converge)
	 	choice depends on rmse or rmsre (slower to converge) and dataset
		recommended:  keep num_node_iterations unchanged (10-20 reasonable), just change the num_network_iterations
	
	 	for EUCLIDEAN: the following is good for (E20|E60, m3|m7)
	 	RMSE: (20,10) iterations is GOOD for PlanetLab, (50, 10) GOOD for King
	 	RMSRE: (>>2000?, 10) GOOD for planetlab (2000 still not converged), (400,10) iterations GOOD for King,
	 	
	 	for SPHERE: the following is good for (E20,m3)
	 	RMSE: (12,10) iterations is GOOD for PlanetLab, (30, 10) GOOD for King
	 	RMSRE: (100, 10) GOOD for planetlab, (100,10) iterations GOOD for King, 
	 	
	 	for HYPER: the following is good for (E20,m3)
	 	RMSE: (70,10) iterations is GOOD for PlanetLab, (50, 10) GOOD for King
	 	RMSRE: (>2000 but 2000 reasonable, 10) for planetlab, (500,10) iterations GOOD for King, 
	 	
	 	
	 	for Seattle dataset: try with m=3, E20|E60, curvature=1/-1
	 	(30,10) for Euclidean, Sphere, Hyper in both RMSE and RMSRE cases
	*/
	public static String error_to_optimize  = "rmsre"; //"rmse" (root mean sqr err or "rmsre" (root mean square of relative error)  
	public static int num_network_iterations = 500; //number of rounds, in each round every node has to update position
	public static int num_node_iterations = 10; // num of position adjustment for each node in each round of position update
	
	
	// INPUT DISSIMILARITY
	int n; // number of nodes (points)
	double[][] F; // input dissimilarity matrix
	// F[i][i]=0, of course
	// F[i][j]=0 for i!=j invalid (unreliable/usable) entry 
	// F[i][j]=F[j,i]>0 for every other i!=j
	
	void loadDissimMatrix(String dissim_filename) {
		F = MyMatrix.loadFromFile(dissim_filename);
		
		if (MyMatrix.isSymmetric(F)==false) {
			System.err.println("Error! loadDissimMatrix(): Dissimilarity matrix F is not symmatric");
			System.exit(-1);
		}
		
		// scale F by multiplying with max(F) to have values in (0, 1)
		// cannot use translation because it will affect Triangle Inequality information
		n = F.length;
		double maxF = MyMatrix.max(F);
		F = MyMatrix.multiplyScalar(1.0/maxF, F);
		for (int i=0; i<n;i++) {
			F[i][i]=0;
			for (int j=0; j<i; j++) {
				if (F[i][j] <= 0) {
					F[i][j] = 0; //set invalid entry to 0 
					F[j][i] = F[i][j];
					System.err.println("Warning! loadDissimMatrix(): Dissimilarity matrix F has INVALID entries");
				}
			}
		}
		// at this point we have a matrix F such that
		// F[i][i]=0, of course
		// F[i][j]=-1 if invalid entry
		// F[i][j]=F[j,i] between (0, 1] for the other cases
		
		System.out.println("dissimilarity file: " + dissim_filename + ", num nodes=" +n);
		System.out.println("........normalized to [0, 1]. Original F max=" + maxF);
		System.out.println("........%TIV = "+ 100.0*numTIV(F));
	}
	
	private double numTIV(double[][] F) {
		// check for triangle inequality violation
		// return %TIV
		int num_tiv = 0;
		int num_triangles = 0;
		
		for (int i=0; i<n; i++)
			for (int j=0; j<i; j++) {
				if (F[i][j]==0) continue;
				for (int k=0; k<j; k++) {
					if (F[i][k]==0 || F[j][k]==0) continue;
					num_triangles++;
					// for a triple (i, j, k) there can only be at most 1 Triangle Inequality violation
					double a = F[i][j];
					double b = F[j][k];
					double c = F[k][i];
					if (a+b < c  || a+c < b || b+c < a) num_tiv++;
				}
			}
		return (double) num_tiv/(double) (num_triangles);
	}
	
	static double error(String type, double[][] truth, double[][] estimate) {	
		boolean[][] included = new boolean[truth.length][truth[0].length];
		for (int i=0;i<truth.length; i++)
			for (int j=0; j<truth[0].length; j++)
				included[i][j] = true;
		return error(type, truth, estimate, included);
	}
	
	
	static double error(String type, double[][] truth, double[][] estimate, boolean[][] included) {
		// only compute error for i!=j 
		int n = truth.length;		// matrix nxn
		double err = 0;
		int count=0;
		
		for (int i=0; i<n; i++) 
			for (int j=0; j<i; j++) {
				if (included[i][j]==false) continue;
				
				if (type.equals("rmse")) {
					err +=  Math.pow(estimate[i][j]-truth[i][j],2);
					count++;
				}
				else if (type.equals("rmsre") && truth[i][j]!=0) {
					err +=  Math.pow((estimate[i][j]-truth[i][j])/truth[i][j],2);
					count++;
				}
				else if (type.equals("mre") && truth[i][j]!=0) {
					err +=  Math.abs((estimate[i][j]-truth[i][j])/truth[i][j]);
					count++;
				}
				else {
					System.err.println("error(): error type not recognized");
					System.exit(-1);
				}
			}
		if (count==0) return 0;
		if (type.equals("rmse") || type.equals("rmsre")) return Math.sqrt(err / (double) count);
		if (type.equals("mre")) return err / (double) count;	
		return 0;
	}
}



		