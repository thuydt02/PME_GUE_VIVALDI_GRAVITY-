package pmegue;

import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;

public class TestDissimEstimate {
	// reconstruct dissimilarity matrix from a small set of known dissimilarity measurements
	
	static DissimEstimate estimator;
	static double graph_train_err, graph_test_err; // using graph-shortest-dist as estimated dist matrix
	
	static int n; // number of nodes
	static double[][] F; // input matrix
	static double[][] W; // weight matrix
	static boolean[][] E; // known matrix: E[i][j] true iff F[i][j] is used for training
	static boolean[][] T; // test matrix: T[i][j] true iff F[i][j] is used for testing

	static void init(String dissim_file, String known_file) {
		estimator = new DissimEstimate(dissim_file, known_file);
		F = estimator.F;
		W = estimator.W;
		E = estimator.E;
		n = estimator.F.length;
		
		T = new boolean[n][n];
		for (int i=0; i<n; i++)
			for (int j=0; j<i; j++)
				if (E[i][j]==false && F[i][j]>0) T[i][j]=true;
	}
	
	static void dissim_Graph(String error_type) {
		// compare to the method using shortest-path length to estimate unknown dissimilarity
		double[][] adjacency_matrix = new double[n][n];
		for (int i=0; i<n; i++)
			for (int j=0; j<i; j++) {
				adjacency_matrix[i][j] = (W[i][j]>0)? F[i][j]: Double.MAX_VALUE;
				adjacency_matrix[j][i] = adjacency_matrix[i][j];
			}
		
		FloydWarshall floydwarshall = new FloydWarshall(n);
        floydwarshall.floydwarshall(adjacency_matrix);
        
        graph_train_err  = InputCommon.error(error_type, F, floydwarshall.distancematrix, E);
		graph_test_err = InputCommon.error(error_type, F, floydwarshall.distancematrix, T);
	}
	
	static private void saveEmbedData(String space,  String output_dir) {
		for (int m: InputCommon.dim_range) {
				// embedding
			String position_out_file = output_dir + "_" + space + "_m"+m+"_MDS.X.csv";
			String dist_out_file = output_dir + "_" + space + "_m"+m+"_MDS.dist.csv";	
			String dissim_out_file = output_dir + "_" + space + "_m"+m+"_MDS.dissim.csv";	
			
			System.out.println("saveEmbedData() : " + position_out_file);
			estimator.run_Embedding(space, m, position_out_file, dist_out_file, dissim_out_file);	
			
		}		
	}
	
	static void reportErrors(String error_type, String output_dir, String result_filename) {		
		dissim_Graph(error_type);
		
		try {
			
			PrintWriter pw = new PrintWriter(result_filename);
			pw.println("m, " +
					"s_train_err, s_test_err, " +
					"h_train_err, h_test_err, " +
					"e_train_err, e_test_err, " +
					"g_train_err, g_test_err");
						
			for (int m: InputCommon.dim_range) {				
				String F_estimate_file;
				String space;
								
				// sphere MDS error
				space = "sphere";
				F_estimate_file= output_dir + "_" + space + "_m"+m+"_MDS.dissim.csv";
				double[][] dissim = MyMatrix.loadFromFile(F_estimate_file);
				double err_train  = InputCommon.error(error_type, F, dissim, E);
				double err_test  = InputCommon.error(error_type, F, dissim, T);
				pw.print(m + ","  + err_train + "," + err_test);				
				
				// hyperbolic MDS error
				space = "hyper";
				F_estimate_file= output_dir + "_" + space + "_m"+m+"_MDS.dissim.csv";
				dissim = MyMatrix.loadFromFile(F_estimate_file);
				err_train  = InputCommon.error(error_type, F, dissim, E);
				err_test  = InputCommon.error(error_type, F, dissim, T);
				pw.print(m + ","  + err_train + "," + err_test);				
				
				
				// euclidean MDS error
				space = "euclidean";
				F_estimate_file= output_dir + "_" + space + "_m"+m+"_MDS.dissim.csv";
				dissim = MyMatrix.loadFromFile(F_estimate_file);
				err_train  = InputCommon.error(error_type, F, dissim, E);
				err_test  = InputCommon.error(error_type, F, dissim, T);
				pw.print(m + ","  + err_train + "," + err_test);				
				
				// graph_embedding error
				pw.println("," + graph_train_err + "," + graph_test_err);
			}
			pw.close();
		}
		catch (IOException e) {
			System.err.println("reportErrors(): " + e.getMessage());
			System.exit(-1);
		}
	}
	
	static String reportErrors_Best(String error_filename) {
		// return best-error of each embedding
		double[][] table = MyMatrix.transpose(MyMatrix.loadFromFile(error_filename, 1));
		
		int h = Misc.getKMIN(table[1], 1)[0];
		int best_m_sphere = (int) table[0][h];
		double trainErr_best_sphere = table[1][h];
		double testErr_best_sphere = table[2][h];
		
		h = Misc.getKMIN(table[3], 1)[0];
		int best_m_hyper = (int) table[0][h];
		double trainErr_best_hyper = table[3][h];
		double testErr_best_hyper = table[4][h];
		
		h = Misc.getKMIN(table[5], 1)[0];
		int best_m_euclidean = (int) table[0][h];
		double trainErr_best_euclidean = table[5][h];
		double testErr_best_euclidean = table[6][h];
		
		double trainErr_best_graph = table[7][0];
		double testErr_best_graph = table[8][0];
		
		return 
				best_m_sphere +"," + 
				best_m_hyper + ","+
				best_m_euclidean + "," + 
				trainErr_best_sphere + "," + 
				trainErr_best_hyper + "," + 
				trainErr_best_euclidean + "," + 
				trainErr_best_graph + "," +
				testErr_best_sphere + "," +
				testErr_best_hyper + "," +
				testErr_best_euclidean + "," +
				testErr_best_graph;
	}
	
	static void run(String output_dir) {
		saveEmbedData("euclidean", output_dir);
		saveEmbedData("sphere", output_dir);
		saveEmbedData("hyper", output_dir);
	}	
	
	public static void main(String[] args) {
		// dissim_file = e.g., 
		// 			"input_NetworkLatency/PlanetLab/PlanetLabData_1"
		//			"input_synthetic/euclidean/D2N100_euclidean_linear"
		// 			"input_synthetic/euclidean/D2N100_euclidean_poly"
		//			"input_synthetic/euclidean/D2N100_euclidean_exp"
		
		// 			input_WTW/wAlpRealFN189_Norm.csv
		
		// known_file = e.g.,
		//			"input_synthetic/W20N100";	 (20% random missing) 
		//			"input_synthetic/euclidean/D2N100_W_LongLinks" (short links are known)
		//			"input_synthetic/euclidean/D2N100_W_ShortLinks" (long links are known)
		
	
		/*
		String dissim_file = "input_WTW/wAlpRealFN189_Norm.csv";
		String missing_file = "input_WTW_Oct13/W100N189";			
		String output_dir = "output_WTW/W100/";
		*/
		
		/*
		String dissim_file = "input_Seattle/SeattleData_2_rtt.csv";
		String known_file = "input_Seattle/E60N99";	
		String output_dir = InputCommon.error_to_optimize + "/output_SeattleData_2_rtt_alp1/E60/";
		*/
		
	/*
		String dissim_file = "input_PlanetLab/PlanetLabData_1.csv";
		String known_file = "input_PlanetLab/E60N490";	
		String output_dir = InputCommon.error_to_optimize + "/output_PlanetLabData_1_alp1/E60/";
			*/
						
		String dissim_file = "input_KingData_363/KingData_363.csv";
		String known_file = "input_KingData_363/E60N363";	
		String output_dir = InputCommon.error_to_optimize + "/output_KingData_363_alp1/E60/";
	
		
		
		if (args.length ==3) {
			dissim_file = args[0];
			known_file = args[1];	
			output_dir = args[2];
		}

		new File(output_dir).mkdir();
	
		init(dissim_file, known_file);
		
		run(output_dir);
		
		if (true) {
			reportErrors("rmse", output_dir,  output_dir + "error_rmse.csv");
			reportErrors("mre", output_dir,  output_dir + "error_mre.csv");
			reportErrors("rmsre", output_dir,  output_dir + "error_rmsre.csv");
			try {
				PrintStream ps = new PrintStream(output_dir+"error_best.csv");
				String rmse_best = reportErrors_Best(output_dir + "error_rmse.csv");
				String rmsre_best = reportErrors_Best(output_dir + "error_rmsre.csv");
				String mre_best = reportErrors_Best(output_dir + "error_mre.csv");
				ps.println("method,	m_s, m_h, m_e, train_s,train_h,train_e,train_g,test_s,test_h,test_e, test_g");
				ps.println("rmse," + rmse_best);
				ps.println("rmsre," + rmsre_best);
				ps.println("mre," + mre_best);
				ps.close();
			}
			catch (IOException e) {
				System.err.println(e.getMessage());
				System.exit(-1);
			}
		}
	}
}