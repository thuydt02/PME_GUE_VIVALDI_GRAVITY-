package pmegue;


import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

public class TestDissimEstimateGvity {
	static DissimEstimateGvity estimator;
	
	static int n; // number of nodes
	static double[][] F; // input matrix
	static double[][] W; // weight matrix
	static boolean[][] E; // known matrix: E[i][j] true iff F[i][j] is used for training
	static boolean[][] T; // test matrix: T[i][j] true iff F[i][j] is used for testing

	public static void init(String dissim_file, String known_file) {
		estimator = new DissimEstimateGvity(dissim_file, known_file);
		F = estimator.F;
		W = estimator.W;
		E = estimator.E;
		n = estimator.F.length;
		T = new boolean[n][n];
		for (int i=0; i<n; i++)
			for (int j=0; j<i; j++) 
				if (E[i][j]==false && F[i][j]>0) {
					T[i][j]=true;
				}
	}
	
	public static void saveEmbedData(String space,  String output_dir) {
		for (int m: InputCommon.dim_range) {
				// embedding
			String position_out_file = output_dir + "_" + space + "_m"+m+"_MDS.X.csv";
			String dist_out_file = output_dir + "_" + space + "_m"+m+"_MDS.dist.csv";	
			//String mass_out_file = output_dir + "_" + space + "_m"+m+"_MDS.mass.csv";	
			//String dissim_out_file = output_dir + "_" + space + "_m"+m+"_MDS.dissim.csv";	
			String dissim_no_mass_out_file = output_dir + "_" + space + "_m"+m+"_MDS.dissim.nomass.csv";
			
			System.out.println("saveEmbedData() : " + position_out_file);
			estimator.run_Embedding(space, m, position_out_file, dist_out_file, 
                                //mass_out_file, dissim_out_file, 
                                dissim_no_mass_out_file);	
			
		}		
	}
	
	public static void run(String space, double[] alpha, String output_dir) {		
		for(double alp: alpha) {
			String case_name = "alpha_" + String.format("%.1f", alp) + "/";
			new File(output_dir+case_name).mkdir();
			System.out.println(case_name);
			estimator.setAlpha(alp);
			saveEmbedData(space, output_dir+case_name);
		}
	}
	public static void reportErrors(String space, String error_type, String output_dir, String result_filename) {			
		try {
			PrintWriter pw = new PrintWriter(result_filename);
			//pw.println("m, mass_train, mass_test, nomass_train, nomass_test");
			pw.println("m,nomass_train,nomass_test");
						
			for (int m: InputCommon.dim_range) {				
				String F_estimate_file= output_dir + "_" + space + "_m"+m+"_MDS.dissim.nomass.csv";
				double[][] dissim = MyMatrix.loadFromFile(F_estimate_file);
				double err_train  = InputCommon.error(error_type, F, dissim, E);
				double err_test  = InputCommon.error(error_type, F, dissim, T);
				pw.println(m + ","  + err_train + "," + err_test);				
				/*
				F_estimate_file= output_dir + "_" + space + "_m"+m+"_MDS.dissim.nomass.csv";
				dissim = MyMatrix.loadFromFile(F_estimate_file);
				err_train  = InputCommon.error(error_type, F, dissim, E);
				err_test  = InputCommon.error(error_type, F, dissim, T);
				pw.println(","  + err_train + "," + err_test);				
				*/
			}
			pw.close();
		}
		catch (IOException e) {
			System.err.println("reportErrors(): " + e.getMessage());
			System.exit(-1);
		}
	}
	
	public static void report1(String space, String error_type, String dissim_file, String known_file, double[] alpha, String output_dir) {
		TestDissimEstimate.init(dissim_file, known_file);

		for(double alp: alpha) {
			String case_name = output_dir + "alpha_" + String.format("%.1f", alp) + "/";		
			System.out.println(case_name);
			
			String error_file = case_name + space + "_" + error_type + ".csv";
			reportErrors(space, error_type, case_name, error_file);
		}
	}
	
	public static void report2(String space, String error_type, double[] alpha, String output_dir) {
		try {
			for (int m : InputCommon.dim_range) {
				String summary_file = output_dir+space+ "_" + error_type + "_m" + m + ".csv";
				PrintWriter pw = new PrintWriter(summary_file);
				//pw.println("alpha, mass_train, mass_test, nomass_train, nomass_test");
				pw.println("alpha,nomass_train,nomass_test");
				
                                for(double alp: alpha) {
					String case_name = output_dir + "alpha_" + String.format("%.1f", alp) + "/";
					String error_file = case_name + space + "_" + error_type + ".csv";
					double[][] table = MyMatrix.transpose(MyMatrix.loadFromFile(error_file, 1));
					int h=0;
					for (h=0; h< table[0].length; h++) {
						if (m==table[0][h]) {
							//pw.println(alp+","+table[1][h] + ","+ table[2][h] +","+table[3][h] + ","+ table[4][h]);	
							pw.println(alp +","+table[1][h] + ","+ table[2][h]);	
							
                                                        break;
						}
					}
				}
				pw.close();
			}			
		}
		catch(IOException e) {
			System.err.println(e.getMessage());
			System.exit(-1);
            }
		
        }
}










//-----------------------------for testing --------------------------------


//	public static void main(String[] args) {
//            runnytaxi195();
//	}
//        
//        
//        public static void runnytaxi195(){
//            
//            String in_dir = "../data/nytaxi/input/";
//            
//            String[] dissim_file = {"nytaxi_traveltimeN195.csv"};
//            
//            String known_file = in_dir + "E/E60N195";
//            //for output
//            String output_dir = "../data/nytaxi/output/gravityN195/"+InputCommon.error_to_optimize + 
//                    String.valueOf(InputCommon.num_network_iterations * InputCommon.num_node_iterations) +  "/E60/";
//            
//            String tmp_dir = "../data/nytaxi/output/gravityN195/";
//            
//            tmp_dir = tmp_dir + InputCommon.error_to_optimize + String.valueOf(InputCommon.num_network_iterations * InputCommon.num_node_iterations)+"/"; 
//            new File(tmp_dir).mkdir();
//            
//            tmp_dir = tmp_dir + "E60/";
//            new File(output_dir).mkdir();
//            
//            int num_dissimFile = dissim_file.length;
//            
//            for (int i = 0; i < num_dissimFile; i++){
//
//                for (int run = 1; run < 100; run++){                  
//                    new File(tmp_dir + "run" + String.valueOf(run) + "/").mkdir();
//                    init(in_dir + dissim_file[i], known_file + "_run" + String.valueOf(run) );
//                    double[] alpha = {1, 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9, 2.0, 2.1, 2.2, 2.3, 2.4, 2.5};//, 2.6, 2.7, 2.8, 2.9, 3};
//                    String[] space = {"euclidean"}; //{"euclidean", "sphere", "hyper"};
//                    String[] error_type ={"rmsre"};// {"rmse"}; //{"rmse", "rmsre", "mre"};
//
//                    for (String s:space) {
//                            run(s, alpha, tmp_dir+"run" + String.valueOf(run) + "/");				
//                            for (String e: error_type) {
//                                    report1(s, e, in_dir + dissim_file[i], known_file+ "_run" + String.valueOf(run), alpha, tmp_dir+ "run" + String.valueOf(run) + "/");
//                                    report2(s, e, alpha, tmp_dir+ "run" + String.valueOf(run) + "/");
//                            }				
//                    }
//                } 
//            }
//            
//        }
//        
//        public static void runHelsinki200(){
//
//            String in_dir = "../data/Helsinki200/input/";
//            
//            String[] dissim_file = {"helsinki"};
//            
//            String known_file = in_dir + "E/E60N195";
//            
//            String output_dir = "../data/Helsinki200/output/gravity/"+InputCommon.error_to_optimize + 
//                    String.valueOf(InputCommon.num_network_iterations * InputCommon.num_node_iterations) +  "/E60/";
//            
//            String tmp_dir = "../data/Helsinki200/output/gravity/";
//            
//            tmp_dir = tmp_dir + InputCommon.error_to_optimize + String.valueOf(InputCommon.num_network_iterations * InputCommon.num_node_iterations)+"/"; 
//            new File(tmp_dir).mkdir();
//            
//            tmp_dir = tmp_dir + "/E60/";
//            new File(output_dir).mkdir();
//            
//            int num_dissimFile = dissim_file.length;
//            
//            for (int i = 0; i < num_dissimFile; i++){
//
//                for (int run = 0; run < 100; run++){                  
//                    new File(tmp_dir + "run" + String.valueOf(run) + "/").mkdir();
//                    init(in_dir + dissim_file[i], known_file + "_run" + String.valueOf(run) );
//                    double[] alpha = {1, 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9, 2.0, 2.1, 2.2, 2.3, 2.4, 2.5};//, 2.6, 2.7, 2.8, 2.9, 3};
//                    String[] space = {"euclidean"}; //{"euclidean", "sphere", "hyper"};
//                    String[] error_type ={"rmsre"};// {"rmse"}; //{"rmse", "rmsre", "mre"};
//
//                    for (String s:space) {
//                            run(s, alpha, tmp_dir+"run" + String.valueOf(run) + "/");				
//                            for (String e: error_type) {
//                                    report1(s, e, in_dir + dissim_file[i], known_file+ "_run" + String.valueOf(run), alpha, tmp_dir+ "run" + String.valueOf(run) + "/");
//                                    report2(s, e, alpha, tmp_dir+ "run" + String.valueOf(run) + "/");
//                            }				
//                    }
//                } 
//            }
//            
//        }
//        
//        public static void runKing363(){
//            
//            String in_dir = "data/king/input/";
//            
//            String[] dissim_file = {"KingData_363.csv"};
//                                   
//            
//            String known_file = in_dir + "E/E60N363";
//            
//            //for output
//            String output_dir = "data/king/180112/"+InputCommon.error_to_optimize + "/E60/";
//            
//            String tmp_dir = "data/king/180112/";
//           // new File(tmp_dir).mkdir();
//            
//            tmp_dir = tmp_dir + InputCommon.error_to_optimize + "/"; 
//           // new File(tmp_dir).mkdir();
//            
//            tmp_dir = tmp_dir + "/E60/";
//            new File(tmp_dir).mkdir();
//            
//            int num_dissimFile = dissim_file.length;
//            
//            for (int i = 0; i < num_dissimFile; i++){
//
//                for (int run = 0; run < 100; run++){                  
//                    new File(tmp_dir + "run" + String.valueOf(run) + "/").mkdir();
//                    init(in_dir + dissim_file[i], known_file + "_run" + String.valueOf(run) );
//                    double[] alpha = {1, 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9, 2.0, 2.1, 2.2, 2.3, 2.4, 2.5};//, 2.6, 2.7, 2.8, 2.9, 3};
//                    String[] space = {"euclidean"}; //{"euclidean", "sphere", "hyper"};
//                    String[] error_type ={"rmsre"};// {"rmse"}; //{"rmse", "rmsre", "mre"};
//
//                    for (String s:space) {
//                            run(s, alpha, tmp_dir+"run" + String.valueOf(run) + "/");				
//                            for (String e: error_type) {
//                                    report1(s, e, in_dir + dissim_file[i], known_file+ "_run" + String.valueOf(run), alpha, tmp_dir+ "run" + String.valueOf(run) + "/");
//                                    report2(s, e, alpha, tmp_dir+ "run" + String.valueOf(run) + "/");
//                            }				
//                    }
//                } 
//            }
//            
//        }
//                
//        public static void run_masspnorm(){
//            //dissim_file = "data/synWTW/input_WTW_Oct13/wAlpRealFN189_Norm.csv";
//            //                    known_file = "data/synWTW/input_WTW_Oct13/E/E20N189";
//            //                    output_dir = "data/synWTW/180105/"+ InputCommon.error_to_optimize + "/E20/";
//            //for inputs
//            
//            String in_dir = "../data/logmpn05_normalized/input/";//"../data/masspnorm/input/";
//            
//            String[] dissim_file = {"mpnorm20N100"};// "mpnorm2N100", 
//                                   // "mpnorm3N100",
//                                  //  "mpnorm4N100", 
//                                   // "mpnorm5N100", //"mpnorm6N100",
//                                    //"mpnorm7N100", "mpnorm8N100", 
//                                 //   "mpnorm9N100"};
//                                   
//            
//            String known_file = in_dir + "E/E60N100";
//            
//            //for output
//            String tmp_dir = "../data/logmpn05_normalized/output/gravity/" + InputCommon.error_to_optimize + "5000/" ;
//            new File(tmp_dir).mkdir();
//            String output_dir = "../data/logmpn05_normalized/output/gravity/" + InputCommon.error_to_optimize + "5000/E60/";
//            new File(output_dir).mkdir();
////"data/synDissimMat/180108/"+InputCommon.error_to_optimize + "/E60/";
//            
//           
//            int num_dissimFile = dissim_file.length;
//            
//            for (int i = 0; i < num_dissimFile; i++){
//                
//                tmp_dir = output_dir + dissim_file[i] + "/";
//                new File(tmp_dir).mkdir();
//            
//                for (int run = 0; run < 100; run++){
//                  
//                    new File(tmp_dir + "run" + String.valueOf(run) + "/").mkdir();
//                    init(in_dir + dissim_file[i], known_file + "_run" + String.valueOf(run) );
//                    double[] alpha = {1, 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9, 2.0, 2.1, 2.2, 2.3, 2.4, 2.5};//, 2.6, 2.7, 2.8, 2.9, 3};
//                    String[] space = {"euclidean"}; //{"euclidean", "sphere", "hyper"};
//                    String[] error_type ={"rmsre"};// {"rmse"}; //{"rmse", "rmsre", "mre"};
//
//                    for (String s:space) {
//                            run(s, alpha, tmp_dir+"run" + String.valueOf(run) + "/");				
//                            for (String e: error_type) {
//                                    report1(s, e, in_dir + dissim_file[i], known_file+ "_run" + String.valueOf(run), alpha, tmp_dir+ "run" + String.valueOf(run) + "/");
//                                    report2(s, e, alpha, tmp_dir+ "run" + String.valueOf(run) + "/");
//                            }				
//                    }
//                } 
//            }
//            
//        }


