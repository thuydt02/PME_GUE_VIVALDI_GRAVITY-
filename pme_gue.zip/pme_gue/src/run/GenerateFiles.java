
package run;
import pmegue.MyMatrix;
import pmegue.Misc;
import java.io.File;

public class GenerateFiles {
	
	
	static int[][] turn0to1(int mat[][], double p) {
		// mat: a nxn 0-1 matrix
		// turn ON p% of the 0-values to 1 in this matrix
		
		int n=mat.length;
		int[][] E = new int[n][n];
		for (int i=0; i<n; i++) 
			for (int j=0; j<i; j++) {
				if (i==j) continue;
				if (mat[i][j] == 1)	E[i][j]=1;
				else if (Math.random()<p) E[i][j]=1;
				E[j][i]=E[i][j];	
			}
		return E;
	}
	
	public static int[][] knownMatrixFile_UniformRandom(int n, double p) {
		// a nxn 0-1 matrix where the 1 entries are chosen uniformly at random

		int[][] W = null;
		while(true) {
			// will break if W forms a connected graph
			// else, continue trying to find a good W
			W = MyMatrix.random_01Matrix_Symmetric(n, p);
			// set all diagonal value to zero
			for (int i=0; i<n; i++) W[i][i] = 0;
			
			boolean continue_flag = false;
			for (int i=0; i<n; i++) {
				int degree_i=0;
				for (int j=0; j<n; j++) {
					if (j==i) continue;
					if (W[i][j]==1) degree_i++;
					if (degree_i >=2) break;
				}
				if (degree_i < 2) {
					// not good for embedding; need at least 2 neighbors for every node
					continue_flag = true;
					break;
				}
			}
			if (continue_flag) continue;
			if (Misc.isConnectedGraph(W)) break;
		}
		return W;
	}
	
	static void missingMatrixFile_RangeBased(boolean short_range, String dissim_file, String output_file) {
		missingMatrixFile_RangeBased(short_range, MyMatrix.loadFromFile(dissim_file), output_file);
	}
	static double missingMatrixFile_RangeBased(boolean short_range, double[][] dist, String output_file) {
		// a nxn 0-1 matrix where 
		// short range: mat(i,j) = 1 if dist(i,j) < range 
		// or in the case of long range:  dist(i,j) > range
		// range is chosen such that resulting matrix should form a minimally connected graph 
		int n=dist.length;	
		double[][] dist1 = new double[n][n];		
		if (short_range) dist1 = dist;
		else {
			// long range
			double max = MyMatrix.max(dist);
			for (int i=0; i<n; i++) {
				for (int j=0; j<i; j++) {
					dist1[i][j] = max- dist[i][j];
					dist1[j][i] = dist1[i][j];
				}
			}
		}
		
		double max_range = Double.MAX_VALUE;
		double min_range = 0;
		double sensor_range;
		int[][] W;
		
		while (true) {
			sensor_range = (min_range+max_range)/2.0;
			W = new int[n][n];
			boolean continue_flag = false;
			for (int i=0; i<n; i++) {
				int num_neighbors=0;
				for (int j=0; j<n; j++) {
					if (j==i) continue;
					if (dist1[i][j] <= sensor_range) {
						W[i][j]=1;
						num_neighbors++;
					}
				}
				if (num_neighbors <2) {
					// not good for embedding
					min_range = sensor_range;
					continue_flag = true;
					break;
				}
			}
			if (continue_flag) continue;
			
			if (Misc.isConnectedGraph(W)) {
				max_range = sensor_range;
				if (max_range - min_range < 0.00001) break;
			}
			else 
				min_range = sensor_range;
		}
		
		// save W matrix
		MyMatrix.saveAs(W, output_file);
		
		return sensor_range;
	}
		
	
	
	static void percentageOf1(String filename) {
		boolean[][] mat = MyMatrix.loadFromFile_Boolean(filename);
		int n=mat.length;
		int count=0;
		for (int i=0; i<n; i++)
			for (int j=0;j<i; j++) 
				if (!mat[i][j]) count++;
		System.out.println("%missing=" + (double) count/(double) (n*(n-1)/2));
	}
	
	
	
	
	
	private static double[][] genPoints(int num_point, int dim){
        //generate uni randomly num_point, each point has dim dimensions
        //return the points with coordinates in (0..1]
        double[][] ret = new double[num_point][dim];
        
        for (int i = 0; i < num_point; i++)
            for (int j = 0; j < dim; j++){
                 ret[i][j] = Math.random();
            }
        return ret;
    }
    
    public static double[][] genDissimMat(int num_point, int dim, double pnorm){
        //return a dissimilarity matrix computed by p norm
        if (pnorm <= 0) return null;
        double[][] points = genPoints(num_point, dim);
        double[][] ret = new double[num_point][num_point];
        double tmp;
        for (int i = 0; i < num_point; i++)
            for (int j = 0; j < i; j++){
                tmp = 0;
                for (int d = 0; d < dim; d++){
                    tmp = tmp + Math.pow(Math.abs(points[i][d] - points[j][d]), pnorm);
                }
                ret[i][j] = Math.pow(tmp, 1.0/pnorm);
                ret[j][i] = ret[i][j];
            }
        return ret;
    }
    //this func comes from Prof
    public static double numTIV(double[][] F) {
		// check for triangle inequality violation
		// return %TIV
		int num_tiv = 0;
		int num_triangles = 0;
		int n = F.length;
                
		for (int i=0; i<n; i++)
			for (int j=0; j<i; j++) {
				if (F[i][j]==0) continue;
				for (int k=0; k<j; k++) {
					if (F[i][k]==0 || F[j][k]==0) continue;
					num_triangles++;
					// for a triple (i, j, k) there can only be at most 1 Triangle Inequality violation
					double a = F[i][j];
					double b = F[j][k];
					double c = F[k][i];
					if (a+b < c  || a+c < b || b+c < a) num_tiv++;
				}
			}
		return (double) num_tiv/(double) (num_triangles);
	}

	
	
	public static void main(String[] args) {
		
		//String dissim_file = "input_PlanetLab/PlanetLabData_1";// "input_WTW/wAlpRealFN189_Norm.csv";
		//String dissim_file = "input_WTW/wAlpRealFN189_Norm.csv";
		//String dissim_file = "input_Seattle/SeattleData_1_rtt.csv";
		
		//String dissim_file = "input_PlanetLab/PlanetLabData_1.csv";
		int n=47;
		
		String out_dir = "E/";
                new File(out_dir).mkdir();
		int[][] E = GenerateFiles.knownMatrixFile_UniformRandom(n, 1);
		MyMatrix.saveAs(E, out_dir + "E100N"+n);
		for (int run=0; run<100; run++) {
			E = GenerateFiles.knownMatrixFile_UniformRandom(n, .2);
			MyMatrix.saveAs(E, out_dir + "E20N"+n+"_run"+run);
			E = turn0to1(E, .25);
			MyMatrix.saveAs(E, out_dir + "E40N"+n+"_run"+run);
			E = turn0to1(E, .33);
			MyMatrix.saveAs(E, out_dir + "E60N"+n+"_run"+run);
			E = turn0to1(E, .5);
			MyMatrix.saveAs(E, out_dir + "E80N"+n+"_run"+run);
		}
		
		
		
		//GenerateFiles.missingMatrixFile_RangeBased(true, dissim_file, "W_short");
		//GenerateFiles.missingMatrixFile_RangeBased(false, dissim_file, "W_long");
		
		//percentageOf1("input_synthetic/euclidean/D2N100_W_ShortLinks");
		//percentageOf1("input_synthetic/euclidean/D2N100_W_LongLinks");
		
	
		

	}
}
