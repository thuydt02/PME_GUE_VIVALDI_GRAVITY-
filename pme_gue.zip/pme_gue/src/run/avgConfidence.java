/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package run;

// this class is dedicated to compute mean, stdevA, margin error of the dataset synDissimMat pnorm = .1 -> .9

import common.Files;
import java.io.File;

public class avgConfidence {
    
    private static final double[] zs = {1.282, 1.44, 1.645, 1.96,2.576,2.807,3.291};
    private static final double[] confid_intervals = {0.8, 0.85, 0.9, 0.95, 0.99, 0.995, 0.999};
    

    public static void computeConfid(String in_file, String out_file, double confid_interval) throws Exception {
        //in_file : the structure is like nomass_train_m3
        //out_file: mean (col1), stdevA (col2), margin error (col3), pme_alp/pme_alp1 (col4, col5, ...)
        //confid_interval = 90% for example =>0.9 
        
        double[][] in_mat = Files.readFile(in_file);
        int num_row = in_mat.length;
        int num_col = in_mat[0].length;
        
        double[][] out_mat = new double[num_row][num_col + 3];
        
        
       
//looking for the z, given confid_level
        int num_z = zs.length;
        double z = 0;
        for (int i = 0; i< num_z; i++){
            
            if (confid_intervals[i] == confid_interval){ 
                z = zs[i]; break;
            }
            if (confid_intervals[i] > confid_interval) break;
        }
        
        if (z == 0){
            System.out.println("latest.PMEConfidence.computeConfid(): cannot find the z for the confidence interval: "
                    + String.valueOf(confid_intervals));
            return;
        }

        double[] mean = new double[num_row]; 
        double stdevA, margin_error;
        
        for (int i = 0; i< num_row; i++){
            mean[i] = 0;
            for (int j = 0; j < num_col; j++){
                mean[i] += in_mat[i][j];
            }
            mean[i] = mean[i] / (double)num_col;
        }
        
        for (int i = 0; i < num_row; i++){
            
            stdevA = 0;
            for (int j = 0; j < num_col; j++){
                stdevA += Math.pow(in_mat[i][j] - mean[i], 2);
                out_mat[i][3+j] = in_mat[i][j];
            }
            stdevA = Math.sqrt(stdevA/(double) (num_col));
            margin_error = z * stdevA / Math.sqrt(num_col);
            
            out_mat[i][0] = mean[i];
            out_mat[i][1] = stdevA;
            out_mat[i][2] = margin_error;
        }
        Files.saveFile(out_mat, out_file);
    }
    
    public static void computeMarginError(String input_dir, String output_dir, int start_run, int end_run, String space) throws Exception{
        String[] m = {"3","5","7"};//{"2","3","5","7","9"};
        int num_m = m.length;
        double confid_interval = 0.999;
        String in_file, out_file;
      
            for (int d = 0; d < num_m; d++){
              
                in_file = input_dir + space + "_rmsre_nomasstrain_m" + m[d] + "_run" + String.valueOf(start_run) + "_" + String.valueOf(end_run) + ".csv";
                out_file = output_dir + "avg_" + space + "_rmsre_nomasstrain_m" + m[d] + "_run" + String.valueOf(start_run) + "_" + String.valueOf(end_run) + ".csv";
                computeConfid(in_file, out_file, confid_interval);
                
                in_file = input_dir + space +  "_rmsre_nomasstest_m" + m[d] + "_run" + String.valueOf(start_run) + "_" + String.valueOf(end_run) + ".csv";
                out_file = output_dir + "avg_" + space + "_rmsre_nomasstest_m" + m[d] + "_run" + String.valueOf(start_run) + "_" + String.valueOf(end_run) + ".csv";
                computeConfid(in_file, out_file, confid_interval);
                
            }
        
        
    }
    
    public static void main(String[] args) throws Exception{
        String space = "hyper";
        String input_dir = "../data/lpnorm500/output/PME_GUE/rmsre5000/E60/" + space + "/";//"../data/traffic-germany47/output/PME_GUE/rmsre5000/E60/euclidean/";//"../data/lpnorm500/output/PME_GUE/lpnorm0.9tiv0.35/rmsre5000/E20/";//"../data/king1740/output/PME_GUE/rmsre5000/E60/";//"../data/synWTW/output/PME_vivaldi/RMSRE/E60/";//"../data/synWTW/output/PME_vivaldi/RMSRE/E20/";
        String output_dir = input_dir;//"../data/synWTW/output/PME_vivaldi/RMSRE/E60/";//"../data/synWTW/output/PME_vivaldi/RMSRE/E20/";
        int start_run = 0;
        int end_run = 19;
        
        
        computeMarginError(input_dir, output_dir, start_run, end_run, space);
        
        
        /*
        String input_dir = "../data/masspnorm/output/gravity/RMSRE5000/E60/";//"../data/synWTW/output/PME_vivaldi/RMSRE/E60/";//"../data/synWTW/output/PME_vivaldi/RMSRE/E20/";
        String output_dir = input_dir;//"../data/synWTW/output/PME_vivaldi/RMSRE/E60/";//"../data/synWTW/output/PME_vivaldi/RMSRE/E20/";
        
        for (int i = 3; i < 10; i++ ){
            String in = input_dir + "mpnorm" + String.valueOf(i) + "N100/";
            String out = in + "confid/";
            new File(out).mkdir();
            computeMarginError(in, out);
        }
*/
    }
}
