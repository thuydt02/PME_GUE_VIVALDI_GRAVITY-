/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package run;

//this class is to collect error (RMSE and RMSRE from 100 runs)

import common.Files;

public class collectRMSREold {
    //private static final String INPUT_DIR = "../data/king1740/output/PME_GUE/rmsre5000/E60/";// "../data/synWTW/output/PME_vivaldi/RMSRE/E20/";
    //private static final String OUTPUT_DIR = "../data/king1740/output/PME_GUE/rmsre5000/E60/";// "../data/synWTW/output/PME_vivaldi/RMSRE/E20/";
    private static final String INPUT_DIR = "../data/traffic-germany47/output/PME_GUE/rmsre5000/E60/euclidean/";//"../data/lpnorm500/output/PME_GUE/lpnorm0.9tiv0.35/rmsre5000/E20/";
    private static final String OUTPUT_DIR = INPUT_DIR;//"";//"../data/lpnorm500/output/PME_GUE/lpnorm0.9tiv0.35/rmsre5000/E20/";
    private static final int[] M = {3,5,7};//{2,3,5,7,9};
    
    
    public static void main(String[] args) throws Exception{
        String input_dir = "";
        String output_dir = "";
        int run_start = 0, run_end = 19;
        int m = 0;
        //int[] tmp = new int[] {1, 5, 9};
        if (args.length == 5){
            input_dir = args[0];
            output_dir = args[1];
            run_start = Integer.parseInt(args[2]);
            run_end = Integer.parseInt(args[3]);
            m = Integer.parseInt(args[4]);
        }
        //collect error for E20/E60 of mpnorm1N100->mpnorm9N100
        //for (int i: tmp){
            int num_alp = 21;
            input_dir = INPUT_DIR ;//+ "mpnorm" + String.valueOf(i) + "N100/";
            output_dir = OUTPUT_DIR;
            collect(input_dir, output_dir, run_start, run_end, m, num_alp);
        //}
    }
    public static void collect(String input_dir, String output_dir, int run_start, int run_end, int m, int num_alp) throws Exception{
        //collect error from run_start to run_end,
        //output error file will be placed in output_dir
        //m = dimension, if m = -1 => collect all dimension
        
        if (input_dir.isEmpty()) input_dir = INPUT_DIR;
        if (output_dir.isEmpty()) output_dir = OUTPUT_DIR;
        int[] dim;
        
        if (m == 0) dim = M;
        else {
            dim = new int[] {m};
        }
        
        String run_dir;
        
        //String[] RMSRE_masstrain_fname = new String[dim.length];//output_dir + "RMSRE_train_m";
        //String[] RMSRE_masstest_fname = new String[dim.length];//output_dir + "RMSRE_test_m";
        String[] RMSRE_nomasstrain_fname = new String[dim.length];//output_dir + "RMSRE_train_m";
        String[] RMSRE_nomasstest_fname = new String[dim.length];//output_dir + "RMSRE_test_m";
        
        int d = 0;
        for (int one_m: dim){
            //RMSRE_masstrain_fname[d] = output_dir + "euclidean_rmsre_masstrain_m" + String.valueOf(one_m)+ "_run" + String.valueOf(run_start) + "_" + String.valueOf(run_end) + ".csv";
            //RMSRE_masstest_fname[d] = output_dir + "euclidean_rmsre_masstest_m" + String.valueOf(one_m)+ "_run" + String.valueOf(run_start) + "_" + String.valueOf(run_end) + ".csv";
            RMSRE_nomasstrain_fname[d] = output_dir + "euclidean_rmsre_nomasstrain_m" + String.valueOf(one_m)+ "_run" + String.valueOf(run_start) + "_" + String.valueOf(run_end) + ".csv";
            RMSRE_nomasstest_fname[d] = output_dir + "euclidean_rmsre_nomasstest_m" + String.valueOf(one_m)+ "_run" + String.valueOf(run_start) + "_" + String.valueOf(run_end) + ".csv";
            
            d++;
        }
        
      
        //double[][] RMSRE_masstrain = new double[16][run_end - run_start + 1];
        //double[][] RMSRE_masstest = new double[16][run_end - run_start + 1];
        double[][] RMSRE_nomasstrain = new double[num_alp][run_end - run_start + 1];
        double[][] RMSRE_nomasstest = new double[num_alp][run_end - run_start + 1];
        
        d = 0;
        
        for (int one_m : dim){
            
        
            for (int run = run_start; run<= run_end; run++){
                run_dir = input_dir + "run" + String.valueOf(run) + "/";
          
                String rmsre_fname_read = run_dir + "euclidean_rmsre_m" + String.valueOf(one_m) + ".csv";
     //           System.out.println(rmsre_fname_read);
                double[][] rmsreMat = Files.readFile(rmsre_fname_read, ",", true); //eliminate the header row if the last parameter = true
       //         System.out.println(String.valueOf(rmsreMat.length));
                for (int row = 0; row < num_alp; row++ ){
             //System.out.println(row);
                    //RMSRE_masstrain[row][run] = rmsreMat[row][1];
                    //RMSRE_masstest[row][run] = rmsreMat[row][2];
                    RMSRE_nomasstrain[row][run] = rmsreMat[row][1];
                    RMSRE_nomasstest[row][run] = rmsreMat[row][2];
                }
                
            }
            
            
            //Files.saveFile(RMSRE_masstrain, RMSRE_masstrain_fname[d]);
            //Files.saveFile(RMSRE_masstest, RMSRE_masstest_fname[d]);
            
            Files.saveFile(RMSRE_nomasstrain, RMSRE_nomasstrain_fname[d]);
            Files.saveFile(RMSRE_nomasstest, RMSRE_nomasstest_fname[d]);
            d++;
        }   
    }
    
    
}
