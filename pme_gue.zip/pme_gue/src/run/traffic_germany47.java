/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package run;
import pmegue.TestDissimEstimateGvity;
import pmegue.InputCommon;
import java.io.File;

public class traffic_germany47 {
            
        static String in_dir = "../data/traffic-germany47/input/";
            
        static String[] dissim_file = {"traffic47.csv"};
                                   
            //for output
        static String output_dir = "../data/traffic-germany47/output/PME_GUE/";// + InputCommon.error_to_optimize + 
                                                    //String.valueOf(InputCommon.num_network_iterations * InputCommon.num_node_iterations) + "/" + EType+"/";
            
public static void main(String[] args){
    int start_run = 0; int end_run = 19;
    String EType = "E60";
    String space = "euclidean";
    runtraffic_germany47(start_run, end_run, EType, space);
}    

 public static void runtraffic_germany47(int start_run, int end_run, String EType, String space){
            
            String known_file = in_dir + "E/" + EType + "N47";
            
            String tmp_dir = output_dir;
            tmp_dir = tmp_dir + InputCommon.error_to_optimize + 
                    String.valueOf(InputCommon.num_network_iterations*InputCommon.num_node_iterations)+"/"; 
            
            new File(tmp_dir).mkdir();
           
            tmp_dir = tmp_dir + EType + "/"; 
            new File(tmp_dir).mkdir();
            
            tmp_dir = tmp_dir + space + "/"; 
            new File(tmp_dir).mkdir();
            
            int num_dissimFile = dissim_file.length;
            
            for (int i = 0; i < num_dissimFile; i++){

                for (int run = start_run; run <= end_run; run++){                  
                    new File(tmp_dir + "run" + String.valueOf(run) + "/").mkdir();
                    TestDissimEstimateGvity.init(in_dir + dissim_file[i], known_file + "_run" + String.valueOf(run) );
                    double[] alpha = {1, 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9, 2.0, 2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 2.7, 2.8, 2.9, 3};
                    //String[] space = {"euclidean"}; //{"euclidean", "sphere", "hyper"};
                    String[] error_type ={"rmsre"};// {"rmse"}; //{"rmse", "rmsre", "mre"};

                    //for (String s:space) {
                            TestDissimEstimateGvity.run(space, alpha, tmp_dir+"run" + String.valueOf(run) + "/");				
                            for (String e: error_type) {
                                    TestDissimEstimateGvity.report1(space, e, in_dir + dissim_file[i], known_file+ "_run" + String.valueOf(run), alpha, tmp_dir+ "run" + String.valueOf(run) + "/");
                                    TestDissimEstimateGvity.report2(space, e, alpha, tmp_dir+ "run" + String.valueOf(run) + "/");
                            }				
                    //}
                } 
            }
            
        }
}
