//this package is to implement the vivaldi algorithm based on the paper: 
//https://www.cs.umd.edu/class/spring2007/cmsc711/papers/vivaldi.pdf
//the vivaldi function will develop according to figure 3 of the paper
package vivaldi;
//this class is to present each coordinate in n dimensions + height

import java.util.Arrays;

public class HeightCoordinate {
	
	public static final double MAX_V = 30000;
	public static final double MAX_H = 30000;
	//public static final int MAX_DIM = 10;

	public double[] v;
	public double h;
	
	public HeightCoordinate(double[] vv, double hh){
		v = new double[vv.length];
                v = Arrays.copyOf(vv, vv.length); 
                h = hh;
	}
	
	public HeightCoordinate add(HeightCoordinate other) {
            
            int dim = this.v.length;
            if (dim != other.v.length) return null;

            double[] nv = new double[dim];
            for (int i = 0; i < dim; i++)
                nv[i] = this.v[i] + other.v[i];
            
            return new HeightCoordinate(nv, Math.abs(this.h + other.h));
	};
	
	public HeightCoordinate sub(HeightCoordinate other) {
		
            int dim = this.v.length;
            if (dim != other.v.length) return null;

            double[] nv = new double[dim];
            for (int i = 0; i < dim; i++)
                nv[i] = this.v[i] - other.v[i];
            
            return new HeightCoordinate(nv, Math.abs(this.h + other.h));
	};
	
	public HeightCoordinate scale(double a) {
            
            int dim = this.v.length;
            if (dim < 1) return null;

            double[] nv = new double[dim];
            for (int i = 0; i < dim; i++)
                nv[i] = this.v[i] * a;
            
            return new HeightCoordinate(nv, this.h * a);
	};
	
	public double measure() {
		
            int dim = this.v.length;
            if (dim < 1) return -1;

            double magnitude = 0;
            for (int i = 0; i < dim; i++) 
                magnitude += Math.pow(this.v[i], 2);

            magnitude = Math.sqrt(magnitude) + this.h;
            return magnitude;

	}
	
	public double distance(HeightCoordinate other) {
	
            HeightCoordinate tmp = new HeightCoordinate(this.v, this.h);
            return tmp.sub(other).measure();
	
	}
	public HeightCoordinate unity() {
	
            double meas = this.measure();
            
            HeightCoordinate hc = null; 
            if (meas != 0) {
                
                hc = new HeightCoordinate(this.v, this.h);
                return hc.scale(1/meas);
            }
            else 
            {
                int dim = this.v.length;
                double[] nv = new double[dim];
                for (int i = 0; i < dim; i++ ) nv[i] = Math.random();
                hc = new HeightCoordinate(nv, Math.random());
                return hc.unity();
            }
            //return hc;

	}
	public double[] getCoordinates() {
            return this.v;
	}
	
	public boolean equals(HeightCoordinate other) {
		
		int dim = this.v.length;
		
		if (dim != other.v.length) return false;
	
                for (int i = 0; i < dim; i++)
                    if (this.v[i] != other.v[i]) return false;
		
		return (Double.compare(this.h, other.h)  == 0);
	}
	
	public boolean atOrigin() {
		
		int dim = this.v.length;
		
		for (int i = 0; i < dim; i++) 
                    if (this.v[i] != 0) 
                            return false;
                    
		return true;
	}
	
	public boolean isValid() {
		
		int dim = this.v.length;
		
		for (int i = 0; i < dim; i++) 
                    if (!validNum(this.v[i]) || (this.v[i] > MAX_V)) 
                        return false;
                    
		
		return validNum(this.h) && (this.h < MAX_H);
	}
	
	private boolean validNum(double v) {
            return Double.isFinite(v);
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
}
