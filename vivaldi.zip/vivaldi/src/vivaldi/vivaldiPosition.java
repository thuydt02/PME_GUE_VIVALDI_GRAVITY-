package vivaldi;
import java.util.Arrays;
//import vivaldi.HeightCoordinate;

public class vivaldiPosition {

    public static final double CONVERGE_EVERY = 5;
    public static final double CONVERGE_FACTOR = 50;
    public static final double ERROR_MIN = 0.1;
    public static final double MAX_RTT = 5*6*1000;

    public static final double cc = 0.25; //0.25
    public static final double ce = 0.5; //0.5
    public static final double initial_error = 10;

    public HeightCoordinate hCoordinate;
    public double error;
    public int nbUpdate;
	
	
    public vivaldiPosition(HeightCoordinate hc){

            this.hCoordinate = hc;
            this.nbUpdate = 0;
            this.error = initial_error;
    }
	
    public vivaldiPosition(HeightCoordinate hc, double er) {

            this.hCoordinate = hc;
            this.nbUpdate = 0;
            this.error = er;
    }
    
    public vivaldiPosition(vivaldiPosition vp){
        if (vp == null) return;
        this.hCoordinate = new HeightCoordinate(vp.hCoordinate.v, vp.hCoordinate.h);
        this.error = vp.error;
        this.nbUpdate = vp.nbUpdate;
    }
	
    public void update(double rtt, vivaldiPosition  other) {

        if (other == null) return;

        HeightCoordinate cj = other.hCoordinate;
        double ej = other.error;
        double ei = this.error;
        
        if (cj == null) return;
        if (!validNum(rtt) || !cj.isValid() || !validNum(ej)) return;
        
        if ((rtt <= 0) || (rtt > MAX_RTT)) return;
        if (ei + ej == 0) return;

        double w = ei / (ej + ei); //(1)

        double re = rtt - this.hCoordinate.distance(cj); //real error 
        double es = Math.abs(re)/rtt; //relative error (2)

        double new_error = es * ce * w + ei * (1 - ce * w); //(3)

        double delta = cc * w;
        double scale = delta * re;

        int dim = this.hCoordinate.v.length;
        if (dim == 0) return;

        double[] noise = new double[dim];
        for (int i = 0; i < dim; i++) noise[i] = Math.random()/10;
        HeightCoordinate randomHC = new HeightCoordinate(noise, 0);

        HeightCoordinate ci = this.hCoordinate;
        HeightCoordinate uij = ci.sub(cj.add(randomHC)).unity();

        HeightCoordinate newHC = ci.add(uij.scale(scale)); //(4)

        if (validNum(new_error) && (newHC.isValid())) {

            this.hCoordinate = newHC;
            this.error = new_error > ERROR_MIN ? new_error: ERROR_MIN;

        }else
        {
            this.hCoordinate = new HeightCoordinate(new double[dim], 0);
            this.error = initial_error;
        }

        /*if (!cj.atOrigin()) this.nbUpdate++;

        if (this.nbUpdate > CONVERGE_EVERY){
//            System.out.println("nbupdate = " + String.valueOf(this.nbUpdate));
            this.nbUpdate = 0;
            vivaldiPosition vp = new vivaldiPosition(new HeightCoordinate(new double[dim],  0), CONVERGE_FACTOR);
            this.update(10, vp);
        }
*/
    }
	
	private boolean validNum(double v) {
		return Double.isFinite(v);
	}
	
		
		
		
	
	public static void main(String[] args) {
		double[] a_random = new double[2];
		vivaldiPosition[] A = new vivaldiPosition[5];
                
                double[] kkk = new double[2];
                kkk[0] = 2;
                kkk[1] = 1;
                
                double[] p2 = {1, 2}; 
                
               double[] noise = {0, 0};
               HeightCoordinate hc1 = new HeightCoordinate(kkk, 0);
               HeightCoordinate hc2 = new HeightCoordinate(p2, 0);
               vivaldiPosition vp1 = new vivaldiPosition(hc1,0);
               vivaldiPosition vp2 = new vivaldiPosition(hc2,0);
        
        double scale = 3;
        HeightCoordinate randomHC = new HeightCoordinate(noise, 0);

        HeightCoordinate ci = vp1.hCoordinate;
        HeightCoordinate cj = vp2.hCoordinate;
        
        System.out.println("ci, cj " + Arrays.toString(ci.v) + Arrays.toString(cj.v));
        System.out.println("ci- cj " + Arrays.toString(ci.sub(cj).v));
        HeightCoordinate uij = ci.sub(cj.add(randomHC)).unity();
        System.out.println("uij = " + Arrays.toString(uij.v));
            System.out.println("ui: " + Arrays.toString(ci.unity().v));
        HeightCoordinate newHC = ci.add(uij.scale(scale)); //(4)
            System.out.println("ci cj " + Arrays.toString(ci.v) + Arrays.toString(cj.v));
        
            vp1.hCoordinate = newHC;
                
                System.out.println("hc2: " + Arrays.toString(hc2.v));
                hc2 = hc2.scale(1.0/4.0);
                System.out.println("scale hc2 by 1/4: " + Arrays.toString(hc2.v));
                System.out.println("unity hc2: " + Arrays.toString(hc2.unity().v));
                
                System.out.println("hc2: " + Arrays.toString(hc2.v));
                System.out.println("hc1 - hc2: " + Arrays.toString((hc1.sub(hc2)).v));
                
                System.out.println("hc2 - hc1: " + Arrays.toString((hc2.sub(hc1)).v));
                
                System.out.println("distance: " + String.valueOf(hc2.distance(hc1)) + " " + String.valueOf(hc1.distance(hc2)));
                System.out.println("distance hc1 -> hc1 " + String.valueOf(hc1.distance(hc1)) );
                
                System.out.println("distance hc2 -> hc2 " + String.valueOf(hc2.distance(hc2)) );
                
                
/*		
		for (int i = 0; i < 5; i++)
		{
			for (int j = 0; j < 2; j++) a_random[j] = Math.random();
			//System.out.println(Arrays.toString(a_random));
			HeightCoordinate hc = new HeightCoordinate(a_random, Math.random());
			A[i] = new vivaldiPosition(hc);
			
		}
                double[][] F = new double[5][5];
                for (int i = 0; i < 5; i++)
                    for (int j = 0; j < 5; j++) F[i][j] = Math.random();
                
                for (int k = 0; k < 9; k++) {
			for (int i = 0; i < 3; i++)
			for (int j = 0; j < 3; j++)
				if (i != j) {
					System.out.println("before: "+ Arrays.toString(A[i].hCoordinate.v));
					A[i].update(F[i][j], A[j]);
					System.out.println("after updated: " + Arrays.toString(A[i].hCoordinate.v));
				}
		}
*/
	}

}
